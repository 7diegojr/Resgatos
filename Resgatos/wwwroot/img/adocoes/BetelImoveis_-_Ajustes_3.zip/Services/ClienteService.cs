using BetelImoveis.Constants;
using BetelImoveis.Data;
using BetelImoveis.Helpers;
using BetelImoveis.Models.Entities;
using BetelImoveis.Models.Enums;
using BetelImoveis.Models.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace BetelImoveis.Services;

public interface IClienteService
{
    /// <summary>
    /// Liga o lead a um cliente (o que tem o mesmo telefone) ou cria um novo, que herda o corretor do lead.
    /// Não confere permissão: quem chama já limitou o lead ao que o usuário pode ver.
    /// </summary>
    Task<ResultadoAcao> ConverterLeadAsync(Lead lead, int usuarioId, CancellationToken ct = default);

    /// <summary>Cadastro manual de cliente (nome, telefone, imóveis e responsável). Esses clientes sempre aparecem na página Clientes.</summary>
    Task<ResultadoAcao> CriarManualAsync(ClienteNovoViewModel dados, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    Task<ClientesViewModel> ListarAsync(ClientesFiltro filtro, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Ficha do cliente. Nulo se não existe ou se o Corretor não pode acessar.</summary>
    Task<ClienteFichaViewModel?> ObterFichaAsync(int id, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Registra uma ligação, mensagem de WhatsApp, proposta ou anotação na linha do tempo do cliente.</summary>
    Task<ResultadoAcao> AdicionarInteracaoAsync(int id, TipoInteracao tipo, string? descricao, bool ehAdmin, int usuarioId, CancellationToken ct = default);
}

/// <summary>
/// Clientes: o Administrador vê todos; o Corretor, os que ele é responsável ou que têm lead dele.
/// A página Clientes lista só quem fechou negócio (tem lead na etapa Fechado: se o lead sair de Fechado, o cliente some da lista)
/// e os clientes cadastrados à mão.
/// </summary>
public class ClienteService : IClienteService
{
    private const int LimiteDescricao = 2000;
    private static readonly ResultadoAcao NaoEncontrado = new(false, "Cliente não encontrado.");

    private readonly AppDbContext _db;
    private readonly IHistoricoService _historico;

    public ClienteService(AppDbContext db, IHistoricoService historico)
    {
        _db = db;
        _historico = historico;
    }

    private IQueryable<Cliente> Escopo(bool ehAdmin, int usuarioId) =>
        ehAdmin
            ? _db.Clientes
            : _db.Clientes.Where(c =>
                (c.CorretorResponsavel != null && c.CorretorResponsavel.UsuarioId == usuarioId)
                || c.Leads.Any(l => l.Corretor != null && l.Corretor.UsuarioId == usuarioId));

    public async Task<ResultadoAcao> ConverterLeadAsync(Lead lead, int usuarioId, CancellationToken ct = default)
    {
        if (lead.ClienteId is not null)
            return new ResultadoAcao(true, "Este lead já é um cliente.");

        var cliente = await _db.Clientes.FirstOrDefaultAsync(c => c.TelefoneNormalizado == lead.TelefoneNormalizado, ct);
        var criado = false;

        if (cliente is null)
        {
            cliente = new Cliente
            {
                Nome = lead.Nome,
                Telefone = lead.Telefone,
                TelefoneNormalizado = lead.TelefoneNormalizado,
                CorretorResponsavelId = lead.CorretorId,
                Ativo = true
            };
            _db.Clientes.Add(cliente);
            criado = true;
        }
        else if (!cliente.Ativo)
        {
            cliente.Ativo = true;
        }

        lead.Cliente = cliente;

        _db.Interacoes.Add(new Interacao
        {
            LeadId = lead.Id,
            UsuarioId = usuarioId,
            Tipo = TipoInteracao.Nota,
            Descricao = criado ? "Lead convertido em cliente." : "Lead ligado ao cliente que já existia (mesmo telefone).",
            DataHora = DateTime.Now
        });

        await _db.SaveChangesAsync(ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.ClienteCriadoDoLead,
            $"Lead #{lead.Id} convertido em cliente #{cliente.Id}.", lead.ImovelId, ct);

        return new ResultadoAcao(true, criado ? "O lead foi convertido em cliente." : "O lead foi ligado ao cliente que já existia.");
    }

    public async Task<ResultadoAcao> CriarManualAsync(ClienteNovoViewModel dados, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var nome = ContatoValidacao.LimparLinha(dados.Nome);
        if (nome.Length is < 2 or > 150)
            return new ResultadoAcao(false, "Informe o nome do cliente.");

        var digitos = ContatoValidacao.SomenteDigitos(dados.Telefone);
        if (!ContatoValidacao.TelefoneValido(digitos))
            return new ResultadoAcao(false, "Informe um telefone válido, com DDD.");

        // Imóveis pelo código público (um ou mais, opcional)
        var codigos = (dados.Codigos ?? string.Empty)
            .Split(new[] { ' ', ',', ';', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(c => CodigoImovelHelper.TentarNormalizar(c))
            .ToList();

        if (codigos.Any(c => c is null))
            return new ResultadoAcao(false, "Um dos códigos de imóvel não está no formato correto (5 caracteres).");

        var lista = codigos.Select(c => c!).Distinct().ToList();
        var imoveis = new List<Imovel>();

        if (lista.Count > 0)
        {
            imoveis = await _db.Imoveis.Include(i => i.Corretor)
                .Where(i => lista.Contains(i.Codigo) && i.DeletedAt == null)
                .ToListAsync(ct);

            // O Corretor só liga ao cliente os imóveis dele
            if (!ehAdmin)
                imoveis = imoveis.Where(i => i.Corretor != null && i.Corretor.UsuarioId == usuarioId).ToList();

            var faltando = lista.Where(c => imoveis.All(i => i.Codigo != c)).ToList();
            if (faltando.Count > 0)
                return new ResultadoAcao(false, "Imóvel não encontrado: " + string.Join(", ", faltando) + ".");
        }

        // Responsável: o Corretor que cadastra fica com o cliente; o Administrador escolhe (ou deixa sem responsável)
        int? corretorId;
        if (!ehAdmin)
        {
            corretorId = await _db.Corretores
                .Where(c => c.UsuarioId == usuarioId && c.Ativo)
                .Select(c => (int?)c.Id)
                .FirstOrDefaultAsync(ct);
        }
        else if (dados.CorretorId is { } escolhido)
        {
            var ok = await _db.Corretores.AnyAsync(c => c.Id == escolhido && c.Ativo && c.Usuario.Ativo, ct);
            if (!ok) return new ResultadoAcao(false, "Corretor não encontrado ou inativo.");
            corretorId = escolhido;
        }
        else
        {
            corretorId = null;
        }

        // Mesmo telefone: não duplica. Se o cliente existente ainda não aparece na lista (nunca fechou negócio), passa a aparecer.
        var cliente = await _db.Clientes.Include(c => c.Imoveis).FirstOrDefaultAsync(c => c.TelefoneNormalizado == digitos, ct);

        if (cliente is not null)
        {
            var visivel = cliente.Manual || await _db.Leads.AnyAsync(l => l.ClienteId == cliente.Id && l.Status == StatusLead.Fechado, ct);
            if (visivel)
                return new ResultadoAcao(false, $"Já existe um cliente com este telefone: {cliente.Nome}.");

            cliente.Manual = true;
            cliente.Ativo = true;
        }
        else
        {
            cliente = new Cliente
            {
                Nome = nome,
                Telefone = ContatoValidacao.FormatarTelefone(digitos),
                TelefoneNormalizado = digitos,
                CorretorResponsavelId = corretorId,
                Ativo = true,
                Manual = true
            };
            _db.Clientes.Add(cliente);
        }

        foreach (var imovel in imoveis.Where(i => cliente.Imoveis.All(x => x.ImovelId != i.Id)))
            cliente.Imoveis.Add(new ClienteImovel { ImovelId = imovel.Id });

        await _db.SaveChangesAsync(ct);

        _db.Interacoes.Add(new Interacao
        {
            ClienteId = cliente.Id,
            UsuarioId = usuarioId,
            Tipo = TipoInteracao.Nota,
            Descricao = "Cliente cadastrado manualmente.",
            DataHora = DateTime.Now
        });
        await _db.SaveChangesAsync(ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.ClienteCadastrado,
            $"Cliente #{cliente.Id} cadastrado manualmente.", imoveis.FirstOrDefault()?.Id, ct);

        return new ResultadoAcao(true, "Cliente cadastrado.");
    }

    public async Task<ClientesViewModel> ListarAsync(ClientesFiltro filtro, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        // Só aparecem: cadastrados à mão ou com algum lead na etapa Fechado
        var consulta = Escopo(ehAdmin, usuarioId).AsNoTracking()
            .Where(c => c.Manual || c.Leads.Any(l => l.Status == StatusLead.Fechado));

        if (filtro.BuscaNormalizada is { } busca)
        {
            var digitos = ContatoValidacao.SomenteDigitos(busca);
            consulta = digitos.Length >= 3
                ? consulta.Where(c => c.Nome.Contains(busca) || c.TelefoneNormalizado.Contains(digitos))
                : consulta.Where(c => c.Nome.Contains(busca) || c.Telefone.Contains(busca));
        }

        consulta = filtro.SituacaoNormalizada switch
        {
            "inativos" => consulta.Where(c => !c.Ativo),
            "todos" => consulta,
            _ => consulta.Where(c => c.Ativo)
        };

        if (ehAdmin && filtro.CorretorId is { } corretorId)
            consulta = consulta.Where(c => c.CorretorResponsavelId == corretorId);

        var total = await consulta.CountAsync(ct);
        var totalPaginas = Math.Max(1, (int)Math.Ceiling(total / (double)ClientesFiltro.TamanhoPagina));
        var pagina = Math.Clamp(filtro.Pagina, 1, totalPaginas);

        var linhas = await consulta
            .OrderBy(c => c.Nome).ThenBy(c => c.Id)
            .Skip((pagina - 1) * ClientesFiltro.TamanhoPagina)
            .Take(ClientesFiltro.TamanhoPagina)
            .Select(c => new ClienteLinha
            {
                Id = c.Id,
                Nome = c.Nome,
                Telefone = c.Telefone,
                Ativo = c.Ativo,
                CorretorNome = c.CorretorResponsavel != null ? c.CorretorResponsavel.Nome : null,
                CreatedAt = c.CreatedAt ?? DateTime.MinValue
            })
            .ToListAsync(ct);

        // Imóveis distintos de cada cliente: os ligados direto a ele (cadastro manual) e os dos leads dele.
        // Consultas separadas: uma subconsulta aninhada gera SQL inválido no MySQL.
        var idsPagina = linhas.Select(l => l.Id).ToList();

        var diretos = await _db.ClienteImoveis.AsNoTracking()
            .Where(ci => idsPagina.Contains(ci.ClienteId))
            .Select(ci => new { ci.ClienteId, ci.ImovelId })
            .ToListAsync(ct);

        var dosLeads = await _db.LeadImoveis.AsNoTracking()
            .Where(li => li.Lead.ClienteId != null && idsPagina.Contains(li.Lead.ClienteId.Value))
            .Select(li => new { ClienteId = li.Lead.ClienteId!.Value, li.ImovelId })
            .ToListAsync(ct);

        foreach (var l in linhas)
        {
            l.QtdImoveis = diretos.Where(p => p.ClienteId == l.Id).Select(p => p.ImovelId)
                .Concat(dosLeads.Where(p => p.ClienteId == l.Id).Select(p => p.ImovelId))
                .Distinct().Count();
        }

        var modelo = new ClientesViewModel
        {
            Filtro = filtro,
            Clientes = linhas,
            Total = total,
            PaginaAtual = pagina,
            TotalPaginas = totalPaginas
        };

        if (ehAdmin)
        {
            modelo.Corretores = await _db.Corretores.AsNoTracking()
                .OrderBy(c => c.Nome)
                .Select(c => new CorretorOpcao { Id = c.Id, Nome = c.Nome, Ativo = c.Ativo && c.Usuario.Ativo })
                .ToListAsync(ct);
        }

        return modelo;
    }

    public async Task<ClienteFichaViewModel?> ObterFichaAsync(int id, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var c = await Escopo(ehAdmin, usuarioId)
            .AsNoTracking()
            .Where(x => x.Id == id)
            .Select(x => new
            {
                x.Id, x.Nome, x.Telefone, x.Observacoes, x.Ativo,
                CorretorNome = x.CorretorResponsavel != null ? x.CorretorResponsavel.Nome : null,
                CreatedAt = x.CreatedAt ?? DateTime.MinValue
            })
            .FirstOrDefaultAsync(ct);

        if (c is null) return null;

        // O Corretor só enxerga os leads dele dentro do cliente
        var leadsDoCliente = _db.Leads.Where(l => l.ClienteId == id);
        if (!ehAdmin)
            leadsDoCliente = leadsDoCliente.Where(l => l.Corretor != null && l.Corretor.UsuarioId == usuarioId);

        var leads = await leadsDoCliente
            .AsNoTracking()
            .OrderByDescending(l => l.CreatedAt)
            .Select(l => new ClienteLeadItem
            {
                Id = l.Id,
                Status = l.Status,
                Origem = l.Origem,
                CreatedAt = l.CreatedAt ?? DateTime.MinValue,
                ImovelCodigo = l.Imovel != null ? l.Imovel.Codigo : null
            })
            .ToListAsync(ct);

        var idsLeads = await leadsDoCliente.Select(l => l.Id).ToListAsync(ct);

        // Imóveis do cliente: os ligados direto a ele e os dos leads dele (ids buscados à parte, em consultas simples)
        var idsImoveis = (await _db.ClienteImoveis.AsNoTracking().Where(ci => ci.ClienteId == id).Select(ci => ci.ImovelId).ToListAsync(ct))
            .Concat(await _db.LeadImoveis.AsNoTracking().Where(li => idsLeads.Contains(li.LeadId)).Select(li => li.ImovelId).ToListAsync(ct))
            .Distinct()
            .ToList();

        var imoveis = await ImovelItens.ListarAsync(_db.Imoveis.Where(i => idsImoveis.Contains(i.Id)), ehAdmin, usuarioId, null, ct);

        var visitas = await _db.Visitas.AsNoTracking()
            .Where(v => idsLeads.Contains(v.LeadId))
            .OrderByDescending(v => v.DataHora)
            .Take(30)
            .Select(v => new LeadVisitaItem
            {
                Id = v.Id,
                DataHora = v.DataHora,
                Status = v.Status,
                Observacoes = v.Observacoes,
                Interesse = v.Interesse,
                FeedbackObservacao = v.FeedbackObservacao,
                CorretorNome = v.Corretor != null ? v.Corretor.Nome : null,
                ImovelCodigo = v.Imovel != null ? v.Imovel.Codigo : null,
                ImovelId = v.ImovelId,
                ImovelAcessivel = v.Imovel != null && v.Imovel.DeletedAt == null
                                  && (ehAdmin || (v.Imovel.Corretor != null && v.Imovel.Corretor.UsuarioId == usuarioId)),
                LeadId = v.LeadId
            })
            .ToListAsync(ct);

        var interacoes = await _db.Interacoes.AsNoTracking()
            .Where(i => i.ClienteId == id || (i.LeadId != null && idsLeads.Contains(i.LeadId.Value)))
            .OrderByDescending(i => i.DataHora).ThenByDescending(i => i.Id)
            .Take(300)
            .Select(i => new InteracaoItem
            {
                Id = i.Id,
                Tipo = i.Tipo,
                Descricao = i.Descricao,
                DataHora = i.DataHora,
                UsuarioNome = i.Usuario != null ? i.Usuario.Nome : null,
                LeadId = i.LeadId
            })
            .ToListAsync(ct);

        return new ClienteFichaViewModel
        {
            Id = c.Id,
            Nome = c.Nome,
            Telefone = c.Telefone,
            Observacoes = c.Observacoes,
            Ativo = c.Ativo,
            CorretorNome = c.CorretorNome,
            CreatedAt = c.CreatedAt,
            Imoveis = imoveis,
            Leads = leads,
            Visitas = visitas,
            Interacoes = interacoes
        };
    }

    public async Task<ResultadoAcao> AdicionarInteracaoAsync(int id, TipoInteracao tipo, string? descricao, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        if (!LeadTexto.TipoManual(tipo))
            return new ResultadoAcao(false, "Escolha um tipo de registro válido.");

        var texto = ContatoValidacao.LimparTexto(descricao);
        if (texto is null)
            return new ResultadoAcao(false, "Escreva o que aconteceu no atendimento.");
        if (texto.Length > LimiteDescricao)
            return new ResultadoAcao(false, $"O texto pode ter até {LimiteDescricao} caracteres.");

        var existe = await Escopo(ehAdmin, usuarioId).AnyAsync(c => c.Id == id, ct);
        if (!existe) return NaoEncontrado;

        _db.Interacoes.Add(new Interacao
        {
            ClienteId = id,
            UsuarioId = usuarioId,
            Tipo = tipo,
            Descricao = texto,
            DataHora = DateTime.Now
        });
        await _db.SaveChangesAsync(ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.InteracaoAdicionada,
            $"{LeadTexto.NomeTipoInteracao(tipo)} no cliente #{id}.", null, ct);

        return new ResultadoAcao(true, "Registro adicionado ao cliente.");
    }
}
