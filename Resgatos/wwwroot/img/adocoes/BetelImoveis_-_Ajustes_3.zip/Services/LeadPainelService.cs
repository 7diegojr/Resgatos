using BetelImoveis.Constants;
using BetelImoveis.Data;
using BetelImoveis.Helpers;
using BetelImoveis.Models.Entities;
using BetelImoveis.Models.Enums;
using BetelImoveis.Models.ViewModels;
using BetelImoveis.Options;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace BetelImoveis.Services;

public interface ILeadPainelService
{
    Task<LeadsViewModel> ListarAsync(LeadsFiltro filtro, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Visão em quadro (kanban): uma coluna por etapa, com os mesmos filtros da lista (exceto a etapa).</summary>
    Task<LeadsViewModel> ListarQuadroAsync(LeadsFiltro filtro, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Ficha do lead. Nulo se não existe ou se o usuário não pode acessar (o Corretor só acessa os dele).</summary>
    Task<LeadFichaViewModel?> ObterFichaAsync(int id, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Quantidade de leads Novos que o usuário enxerga (contador da sidebar).</summary>
    Task<int> ContarNovosAsync(bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Muda a etapa do funil (menos Perdido e Fechado, que pedem dados). Gera interação e histórico.</summary>
    Task<ResultadoAcao> AlterarEtapaAsync(int id, StatusLead etapa, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Fecha o negócio: escolhe o imóvel, o tipo e o valor e, se pedido, muda o imóvel para Vendido ou Alugado.</summary>
    Task<ResultadoAcao> FecharAsync(LeadFechamentoViewModel dados, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Marca o lead como Perdido, com motivo obrigatório.</summary>
    Task<ResultadoAcao> MarcarComoPerdidoAsync(int id, MotivoPerda motivo, string? observacao, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Registro manual do corretor: ligação, WhatsApp, proposta conversada ou anotação.</summary>
    Task<ResultadoAcao> AdicionarInteracaoAsync(int id, TipoInteracao tipo, string? descricao, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Cadastro manual de lead (indicação, ligação, balcão).</summary>
    Task<ResultadoAcao> CriarManualAsync(LeadNovoViewModel dados, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Troca o corretor responsável (ou deixa sem dono). Só o Administrador (checado no Controller).</summary>
    Task<ResultadoAcao> ReatribuirAsync(int id, int? corretorId, int usuarioId, CancellationToken ct = default);

    /// <summary>Liga mais um imóvel ao lead, pelo código público.</summary>
    Task<ResultadoAcao> AdicionarImovelAsync(int id, string? codigo, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    Task<ResultadoAcao> RemoverImovelAsync(int id, int imovelId, bool ehAdmin, int usuarioId, CancellationToken ct = default);

    /// <summary>Exclui o lead e tudo o que é ligado a ele (exclusão de dados, LGPD). Só o Administrador.</summary>
    Task<ResultadoAcao> ExcluirAsync(int id, int usuarioId, CancellationToken ct = default);
}

/// <summary>
/// Painel de leads. O Administrador vê tudo; o Corretor, só os leads do corretor vinculado ao seu usuário
/// (todas as consultas passam por <see cref="Escopo"/>). Para o que o Corretor não pode ver, a resposta é a de um lead inexistente.
/// Nas mensagens do Histórico o lead aparece só pelo código (sem nome nem telefone).
/// </summary>
public class LeadPainelService : ILeadPainelService
{
    /// <summary>Quantos cartões cada coluna do quadro mostra. O total da coluna aparece mesmo quando há mais.</summary>
    public const int CartoesPorColuna = 20;

    private const int MaximoInteracoes = 200;
    private const int LimiteDescricao = 2000;
    private const int LimiteObservacaoPerda = 200;

    private static readonly ResultadoAcao NaoEncontrado = new(false, "Lead não encontrado.");

    private readonly AppDbContext _db;
    private readonly IHistoricoService _historico;
    private readonly IClienteService _clientes;
    private readonly IImovelService _imoveis;
    private readonly LeadsOptions _opcoes;
    private readonly ILogger<LeadPainelService> _logger;

    public LeadPainelService(AppDbContext db, IHistoricoService historico, IClienteService clientes, IImovelService imoveis,
        IOptions<LeadsOptions> opcoes, ILogger<LeadPainelService> logger)
    {
        _db = db;
        _historico = historico;
        _clientes = clientes;
        _imoveis = imoveis;
        _opcoes = opcoes.Value;
        _logger = logger;
    }

    // ---------- Escopo (permissão) ----------
    private IQueryable<Lead> Escopo(bool ehAdmin, int usuarioId) =>
        ehAdmin
            ? _db.Leads
            : _db.Leads.Where(l => l.Corretor != null && l.Corretor.UsuarioId == usuarioId);

    private int? DiasNaEtapa(StatusLead status, DateTime? etapaAlteradaEm, DateTime? criadoEm)
    {
        if (status is StatusLead.Fechado or StatusLead.Perdido) return null;
        var desde = etapaAlteradaEm ?? criadoEm;
        return desde is null ? null : Math.Max(0, (int)(DateTime.Now - desde.Value).TotalDays);
    }

    private static IQueryable<Lead> Filtrar(IQueryable<Lead> consulta, LeadsFiltro filtro, bool ehAdmin, bool comEtapa)
    {
        if (filtro.BuscaNormalizada is { } busca)
        {
            var digitos = ContatoValidacao.SomenteDigitos(busca);

            consulta = digitos.Length >= 3
                ? consulta.Where(l => l.Nome.Contains(busca) || l.TelefoneNormalizado.Contains(digitos))
                : consulta.Where(l => l.Nome.Contains(busca) || l.Telefone.Contains(busca));
        }

        // No quadro todas as etapas aparecem (cada uma é uma coluna): o filtro de etapa só vale na lista
        if (comEtapa && filtro.StatusEnum is { } status)
            consulta = consulta.Where(l => l.Status == status);

        if (filtro.OrigemEnum is { } origem)
            consulta = consulta.Where(l => l.Origem == origem);

        // O filtro por corretor só existe para o Administrador
        if (ehAdmin)
        {
            if (filtro.SemCorretor)
                consulta = consulta.Where(l => l.CorretorId == null);
            else if (filtro.CorretorId is { } corretorId)
                consulta = consulta.Where(l => l.CorretorId == corretorId);
        }

        if (filtro.De is { } de)
        {
            var inicio = de.ToDateTime(TimeOnly.MinValue);
            consulta = consulta.Where(l => l.CreatedAt >= inicio);
        }

        if (filtro.Ate is { } ate)
        {
            // Inclui o dia inteiro: vale até 23:59:59 da data escolhida
            var fim = ate.AddDays(1).ToDateTime(TimeOnly.MinValue);
            consulta = consulta.Where(l => l.CreatedAt < fim);
        }

        return consulta;
    }

    private static IQueryable<Lead> Ordenar(IQueryable<Lead> consulta, LeadsFiltro filtro) =>
        filtro.OrdenarNormalizado switch
        {
            "antigos" => consulta.OrderBy(l => l.CreatedAt).ThenBy(l => l.Id),
            "nome" => consulta.OrderBy(l => l.Nome).ThenByDescending(l => l.Id),
            _ => consulta.OrderByDescending(l => l.CreatedAt).ThenByDescending(l => l.Id)
        };

    private IQueryable<LeadLinha> ParaLinha(IQueryable<Lead> consulta, bool ehAdmin, int usuarioId) =>
        consulta.Select(l => new LeadLinha
        {
            Id = l.Id,
            Nome = l.Nome,
            Telefone = l.Telefone,
            Origem = l.Origem,
            Assunto = l.Assunto,
            Status = l.Status,
            CreatedAt = l.CreatedAt ?? DateTime.MinValue,
            EtapaAlteradaEm = l.EtapaAlteradaEm,
            ImovelId = l.ImovelId,
            ImovelCodigo = l.Imovel != null ? l.Imovel.Codigo : null,
            ImovelAcessivel = l.Imovel != null && l.Imovel.DeletedAt == null
                              && (ehAdmin || (l.Imovel.Corretor != null && l.Imovel.Corretor.UsuarioId == usuarioId)),
            QtdImoveis = l.Imoveis.Count(),
            CorretorId = l.CorretorId,
            CorretorNome = l.Corretor != null ? l.Corretor.Nome : null,
            CorretorFotoUrl = l.Corretor != null ? l.Corretor.FotoUrl : null
        });

    private void PreencherDias(IEnumerable<LeadLinha> linhas)
    {
        foreach (var l in linhas)
        {
            l.DiasNaEtapa = DiasNaEtapa(l.Status, l.EtapaAlteradaEm, l.CreatedAt);
            l.Parado = l.DiasNaEtapa is { } d && d >= _opcoes.DiasParado;
        }
    }

    private async Task<List<CorretorOpcao>> ListarCorretoresAsync(bool somenteAtivos, CancellationToken ct)
    {
        var consulta = _db.Corretores.AsNoTracking().AsQueryable();
        if (somenteAtivos) consulta = consulta.Where(c => c.Ativo && c.Usuario.Ativo);

        return await consulta
            .OrderBy(c => c.Nome)
            .Select(c => new CorretorOpcao { Id = c.Id, Nome = c.Nome, Ativo = c.Ativo && c.Usuario.Ativo })
            .ToListAsync(ct);
    }

    // ---------- Lista ----------
    public async Task<LeadsViewModel> ListarAsync(LeadsFiltro filtro, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var consulta = Ordenar(Filtrar(Escopo(ehAdmin, usuarioId).AsNoTracking(), filtro, ehAdmin, comEtapa: true), filtro);

        var total = await consulta.CountAsync(ct);
        var totalPaginas = Math.Max(1, (int)Math.Ceiling(total / (double)LeadsFiltro.TamanhoPagina));
        var pagina = Math.Clamp(filtro.Pagina, 1, totalPaginas);

        var linhas = await ParaLinha(consulta.Skip((pagina - 1) * LeadsFiltro.TamanhoPagina).Take(LeadsFiltro.TamanhoPagina), ehAdmin, usuarioId)
            .ToListAsync(ct);
        PreencherDias(linhas);

        var modelo = new LeadsViewModel
        {
            Filtro = filtro,
            Leads = linhas,
            Total = total,
            PaginaAtual = pagina,
            TotalPaginas = totalPaginas,
            DiasParado = _opcoes.DiasParado
        };

        await PreencherAdminAsync(modelo, ehAdmin, ct);
        return modelo;
    }

    // ---------- Quadro (kanban) ----------
    public async Task<LeadsViewModel> ListarQuadroAsync(LeadsFiltro filtro, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var baseConsulta = Filtrar(Escopo(ehAdmin, usuarioId).AsNoTracking(), filtro, ehAdmin, comEtapa: false);

        var totais = await baseConsulta
            .GroupBy(l => l.Status)
            .Select(g => new { Status = g.Key, Total = g.Count() })
            .ToDictionaryAsync(x => x.Status, x => x.Total, ct);

        var colunas = new List<LeadsQuadroColuna>();

        foreach (var etapa in Enum.GetValues<StatusLead>())
        {
            var cartoes = await ParaLinha(Ordenar(baseConsulta.Where(l => l.Status == etapa), filtro).Take(CartoesPorColuna), ehAdmin, usuarioId)
                .ToListAsync(ct);
            PreencherDias(cartoes);

            colunas.Add(new LeadsQuadroColuna
            {
                Etapa = etapa,
                Total = totais.GetValueOrDefault(etapa),
                Cartoes = cartoes
            });
        }

        var modelo = new LeadsViewModel
        {
            Filtro = filtro,
            Total = colunas.Sum(c => c.Total),
            Colunas = colunas,
            DiasParado = _opcoes.DiasParado
        };

        await PreencherAdminAsync(modelo, ehAdmin, ct);
        return modelo;
    }

    private async Task PreencherAdminAsync(LeadsViewModel modelo, bool ehAdmin, CancellationToken ct)
    {
        if (!ehAdmin) return;

        modelo.Corretores = await ListarCorretoresAsync(somenteAtivos: false, ct);
        modelo.SemResponsavel = await _db.Leads
            .AsNoTracking()
            .CountAsync(l => l.CorretorId == null && l.Status != StatusLead.Fechado && l.Status != StatusLead.Perdido, ct);
    }

    // ---------- Ficha ----------
    public async Task<LeadFichaViewModel?> ObterFichaAsync(int id, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var d = await Escopo(ehAdmin, usuarioId)
            .AsNoTracking()
            .Where(l => l.Id == id)
            .Select(l => new
            {
                l.Id, l.Nome, l.Telefone, l.Mensagem, l.Origem, l.Assunto, l.Status, l.MotivoPerda, l.ObservacaoPerda,
                l.TipoNegocio, l.ValorNegocio, l.EncerradoEm, l.CreatedAt, l.PrimeiroAtendimentoEm, l.EtapaAlteradaEm,
                l.ImovelId, l.CorretorId, l.ClienteId,
                ClienteNome = l.Cliente != null ? l.Cliente.Nome : null,
                CorretorNome = l.Corretor != null ? l.Corretor.Nome : null,
                CorretorAtivo = l.Corretor != null && l.Corretor.Ativo && l.Corretor.Usuario.Ativo
            })
            .FirstOrDefaultAsync(ct);

        if (d is null) return null;

        var imoveis = await ImovelItens.ListarAsync(
            _db.LeadImoveis.Where(li => li.LeadId == id).Select(li => li.Imovel), ehAdmin, usuarioId, d.ImovelId, ct);

        var interacoes = await _db.Interacoes
            .AsNoTracking()
            .Where(i => i.LeadId == id)
            .OrderByDescending(i => i.DataHora).ThenByDescending(i => i.Id)
            .Take(MaximoInteracoes)
            .Select(i => new InteracaoItem
            {
                Id = i.Id,
                Tipo = i.Tipo,
                Descricao = i.Descricao,
                DataHora = i.DataHora,
                UsuarioNome = i.Usuario != null ? i.Usuario.Nome : null
            })
            .ToListAsync(ct);

        var visitas = await _db.Visitas
            .AsNoTracking()
            .Where(v => v.LeadId == id)
            .OrderByDescending(v => v.DataHora).ThenByDescending(v => v.Id)
            .Take(30)
            .Select(v => new LeadVisitaItem
            {
                Id = v.Id,
                DataHora = v.DataHora,
                Status = v.Status,
                Observacoes = v.Observacoes,
                Interesse = v.Interesse,
                FeedbackObservacao = v.FeedbackObservacao,
                CorretorNome = v.Corretor != null ? v.Corretor.Nome : null,
                ImovelCodigo = v.Imovel != null ? v.Imovel.Codigo : null,
                ImovelId = v.ImovelId,
                ImovelAcessivel = v.Imovel != null && v.Imovel.DeletedAt == null
                                  && (ehAdmin || (v.Imovel.Corretor != null && v.Imovel.Corretor.UsuarioId == usuarioId))
            })
            .ToListAsync(ct);

        var dias = DiasNaEtapa(d.Status, d.EtapaAlteradaEm, d.CreatedAt);

        return new LeadFichaViewModel
        {
            Id = d.Id,
            Nome = d.Nome,
            Telefone = d.Telefone,
            Mensagem = d.Mensagem,
            Origem = d.Origem,
            Assunto = d.Assunto,
            Status = d.Status,
            MotivoPerda = d.MotivoPerda,
            ObservacaoPerda = d.ObservacaoPerda,
            TipoNegocio = d.TipoNegocio,
            ValorNegocio = d.ValorNegocio,
            EncerradoEm = d.EncerradoEm,
            CreatedAt = d.CreatedAt ?? DateTime.MinValue,
            PrimeiroAtendimentoEm = d.PrimeiroAtendimentoEm,
            DiasNaEtapa = dias,
            Parado = dias is { } n && n >= _opcoes.DiasParado,
            Imoveis = imoveis,
            CorretorId = d.CorretorId,
            CorretorNome = d.CorretorNome,
            CorretorAtivo = d.CorretorAtivo,
            ClienteId = d.ClienteId,
            ClienteNome = d.ClienteNome,
            Interacoes = interacoes,
            Visitas = visitas,
            Corretores = ehAdmin ? await ListarCorretoresAsync(somenteAtivos: true, ct) : new List<CorretorOpcao>()
        };
    }

    public Task<int> ContarNovosAsync(bool ehAdmin, int usuarioId, CancellationToken ct = default) =>
        Escopo(ehAdmin, usuarioId).AsNoTracking().CountAsync(l => l.Status == StatusLead.Novo, ct);

    // ---------- Etapas ----------
    public async Task<ResultadoAcao> AlterarEtapaAsync(int id, StatusLead etapa, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        if (!Enum.IsDefined(etapa))
            return new ResultadoAcao(false, "Escolha uma etapa válida.");

        if (etapa == StatusLead.Perdido)
            return new ResultadoAcao(false, "Para marcar como perdido, informe o motivo.");

        if (etapa == StatusLead.Fechado)
            return new ResultadoAcao(false, "Para fechar o negócio, confirme os dados do fechamento.");

        var lead = await Escopo(ehAdmin, usuarioId).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NaoEncontrado;

        if (lead.Status == etapa)
            return new ResultadoAcao(true, $"O lead já estava em \"{LeadTexto.NomeStatus(etapa)}\".");

        await AplicarEtapaAsync(lead, etapa, null, null, usuarioId, null, ct);

        return new ResultadoAcao(true, $"O lead foi movido para \"{LeadTexto.NomeStatus(etapa)}\".");
    }

    public async Task<ResultadoAcao> MarcarComoPerdidoAsync(int id, MotivoPerda motivo, string? observacao, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        if (!Enum.IsDefined(motivo))
            return new ResultadoAcao(false, "Informe o motivo da perda.");

        var obs = ContatoValidacao.LimparLinha(observacao);
        if (obs.Length > LimiteObservacaoPerda)
            return new ResultadoAcao(false, $"A observação pode ter até {LimiteObservacaoPerda} caracteres.");

        var lead = await Escopo(ehAdmin, usuarioId).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NaoEncontrado;

        if (lead.Status == StatusLead.Perdido)
            return new ResultadoAcao(true, "O lead já estava como perdido.");

        await AplicarEtapaAsync(lead, StatusLead.Perdido, motivo, obs.Length == 0 ? null : obs, usuarioId, null, ct);

        return new ResultadoAcao(true, "O lead foi marcado como perdido.");
    }

    public async Task<ResultadoAcao> FecharAsync(LeadFechamentoViewModel dados, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var lead = await Escopo(ehAdmin, usuarioId)
            .Include(l => l.Imoveis).ThenInclude(li => li.Imovel).ThenInclude(i => i.Corretor)
            .FirstOrDefaultAsync(l => l.Id == dados.Id, ct);
        if (lead is null) return NaoEncontrado;

        if (lead.Status == StatusLead.Fechado)
            return new ResultadoAcao(true, "O negócio já estava fechado.");

        // Imóvel do negócio: o escolhido (precisa ser um dos ligados ao lead) ou o único que o lead tem
        Imovel? imovel = null;
        if (dados.ImovelId is { } imovelId)
        {
            imovel = lead.Imoveis.Select(li => li.Imovel).FirstOrDefault(i => i.Id == imovelId);
            if (imovel is null)
                return new ResultadoAcao(false, "Escolha um dos imóveis deste lead.");
        }
        else if (lead.Imoveis.Count == 1)
        {
            imovel = lead.Imoveis.First().Imovel;
        }
        else if (lead.Imoveis.Count > 1)
        {
            return new ResultadoAcao(false, "Escolha o imóvel do negócio.");
        }

        // Tipo do negócio: o escolhido, senão o do imóvel (quando só tem uma finalidade) ou o que o lead já tinha
        FinalidadeImovel? tipo = dados.Tipo?.Trim().ToLowerInvariant() switch
        {
            "venda" => FinalidadeImovel.Venda,
            "aluguel" => FinalidadeImovel.Aluguel,
            _ => LeadCriador.TipoDoImovel(imovel) ?? lead.TipoNegocio
        };

        if (tipo is null)
            return new ResultadoAcao(false, "Informe se o negócio foi uma venda ou um aluguel.");

        if (imovel is not null && imovel.Finalidade != FinalidadeImovel.Ambos && imovel.Finalidade != tipo)
            return new ResultadoAcao(false, "O tipo do negócio não combina com a finalidade do imóvel.");

        // Valor: o digitado ou o preço do imóvel
        decimal? valor;
        if (string.IsNullOrWhiteSpace(dados.Valor))
        {
            valor = tipo == FinalidadeImovel.Venda ? imovel?.PrecoVenda : imovel?.PrecoAluguel;
        }
        else if (NumeroBr.Tentar(dados.Valor, out var digitado) && digitado is { } v and >= 0 and < 1_000_000_000m)
        {
            valor = v;
        }
        else
        {
            return new ResultadoAcao(false, "Informe um valor válido para o negócio.");
        }

        lead.TipoNegocio = tipo;
        lead.ValorNegocio = valor;
        if (imovel is not null) lead.ImovelId = imovel.Id;

        // Status do imóvel: o sistema sugere (marcado por padrão) e o corretor confirma
        string? avisoImovel = null;
        if (dados.AtualizarImovel && imovel is not null)
        {
            var pode = ehAdmin || (imovel.Corretor is not null && imovel.Corretor.UsuarioId == usuarioId);
            if (!pode)
            {
                avisoImovel = "O status do imóvel não foi alterado porque ele é de outro corretor.";
            }
            else
            {
                var novo = tipo == FinalidadeImovel.Venda ? StatusImovel.Vendido : StatusImovel.Alugado;
                var r = await _imoveis.AlterarStatusAsync(imovel.Id, novo, usuarioId, ct);
                avisoImovel = r.Sucesso
                    ? $"O imóvel {imovel.Codigo} foi marcado como {ImovelTexto.NomeStatus(novo)}."
                    : "O status do imóvel não pôde ser alterado: " + r.Mensagem;
            }
        }

        await AplicarEtapaAsync(lead, StatusLead.Fechado, null, null, usuarioId, imovel, ct);

        return new ResultadoAcao(true, "Negócio fechado." + (avisoImovel is null ? "" : " " + avisoImovel));
    }

    /// <summary>
    /// Troca a etapa, preenche o primeiro atendimento (ao sair de Novo pela primeira vez) e registra a mudança na linha do
    /// tempo e no Histórico. A etapa e a interação são salvas juntas, em um único SaveChanges.
    /// </summary>
    private async Task AplicarEtapaAsync(Lead lead, StatusLead nova, MotivoPerda? motivo, string? observacao, int usuarioId, Imovel? imovelFechado, CancellationToken ct)
    {
        var anterior = lead.Status;
        var agora = DateTime.Now;

        if (anterior == StatusLead.Novo && lead.PrimeiroAtendimentoEm is null)
            lead.PrimeiroAtendimentoEm = agora;

        lead.Status = nova;
        lead.EtapaAlteradaEm = agora;
        lead.EncerradoEm = nova is StatusLead.Fechado or StatusLead.Perdido ? agora : null;
        lead.MotivoPerda = nova == StatusLead.Perdido ? motivo : null;
        lead.ObservacaoPerda = nova == StatusLead.Perdido ? observacao : null;

        if (nova != StatusLead.Fechado && anterior == StatusLead.Fechado)
            lead.ValorNegocio = null;

        TipoInteracao tipo;
        string descricao;

        if (nova == StatusLead.Fechado)
        {
            tipo = TipoInteracao.Fechado;
            descricao = $"Negócio fechado ({LeadTexto.NomeNegocio(lead.TipoNegocio).ToLowerInvariant()})"
                        + (imovelFechado is null ? "" : $" do imóvel {imovelFechado.Codigo}")
                        + (lead.ValorNegocio is { } v ? $" por {FormatHelper.Moeda(v)}" : "") + ".";
        }
        else if (nova == StatusLead.Perdido)
        {
            tipo = TipoInteracao.Perdido;
            descricao = $"Negócio perdido. Motivo: {LeadTexto.NomeMotivo(motivo ?? MotivoPerda.Outro)}.";
            if (!string.IsNullOrEmpty(observacao)) descricao += $" {observacao}";
        }
        else
        {
            tipo = TipoInteracao.MudancaEtapa;
            descricao = $"Etapa alterada de \"{LeadTexto.NomeStatus(anterior)}\" para \"{LeadTexto.NomeStatus(nova)}\".";
        }

        _db.Interacoes.Add(new Interacao
        {
            LeadId = lead.Id,
            UsuarioId = usuarioId,
            Tipo = tipo,
            Descricao = descricao,
            DataHora = agora
        });

        await _db.SaveChangesAsync(ct);

        // Ao fechar o negócio, o lead vira cliente automaticamente (se ainda não for).
        // A etapa já foi salva: se a conversão falhar, o lead continua na nova etapa e o erro vai para o log.
        if (nova == StatusLead.Fechado && lead.ClienteId is null)
        {
            try
            {
                await _clientes.ConverterLeadAsync(lead, usuarioId, ct);
            }
            catch (Exception ex) when (ex is not OperationCanceledException)
            {
                _logger.LogError(ex, "Falha ao converter o lead {LeadId} em cliente.", lead.Id);
            }
        }

        var acao = nova switch
        {
            StatusLead.Perdido => HistoricoAcoes.LeadPerdido,
            StatusLead.Fechado => HistoricoAcoes.LeadFechado,
            _ => HistoricoAcoes.LeadEtapaAlterada
        };

        await _historico.RegistrarAsync(usuarioId, acao,
            nova == StatusLead.Perdido
                ? $"Lead #{lead.Id} marcado como perdido (motivo: {LeadTexto.NomeMotivo(motivo ?? MotivoPerda.Outro)})."
                : nova == StatusLead.Fechado
                    ? $"Lead #{lead.Id}: negócio fechado ({LeadTexto.NomeNegocio(lead.TipoNegocio).ToLowerInvariant()})."
                    : $"Lead #{lead.Id}: de \"{LeadTexto.NomeStatus(anterior)}\" para \"{LeadTexto.NomeStatus(nova)}\".",
            lead.ImovelId, ct);

        _logger.LogInformation("Lead {LeadId}: etapa {De} → {Para} (usuário {UsuarioId}).", lead.Id, anterior, nova, usuarioId);
    }

    // ---------- Interações manuais ----------
    public async Task<ResultadoAcao> AdicionarInteracaoAsync(int id, TipoInteracao tipo, string? descricao, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        if (!LeadTexto.TipoManual(tipo))
            return new ResultadoAcao(false, "Escolha um tipo de registro válido.");

        var texto = ContatoValidacao.LimparTexto(descricao);
        if (texto is null)
            return new ResultadoAcao(false, "Escreva o que aconteceu no atendimento.");

        if (texto.Length > LimiteDescricao)
            return new ResultadoAcao(false, $"O texto pode ter até {LimiteDescricao} caracteres.");

        var lead = await Escopo(ehAdmin, usuarioId).AsNoTracking().FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NaoEncontrado;

        _db.Interacoes.Add(new Interacao
        {
            LeadId = lead.Id,
            UsuarioId = usuarioId,
            Tipo = tipo,
            Descricao = texto,
            DataHora = DateTime.Now
        });

        await _db.SaveChangesAsync(ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.InteracaoAdicionada,
            $"{LeadTexto.NomeTipoInteracao(tipo)} no lead #{lead.Id}.", lead.ImovelId, ct);

        return new ResultadoAcao(true, "Registro adicionado ao lead.");
    }

    // ---------- Cadastro manual ----------
    public async Task<ResultadoAcao> CriarManualAsync(LeadNovoViewModel dados, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var nome = ContatoValidacao.LimparLinha(dados.Nome);
        if (nome.Length is < 2 or > 150)
            return new ResultadoAcao(false, "Informe o nome da pessoa.");

        var digitos = ContatoValidacao.SomenteDigitos(dados.Telefone);
        if (!ContatoValidacao.TelefoneValido(digitos))
            return new ResultadoAcao(false, "Informe um telefone válido, com DDD.");

        var mensagem = ContatoValidacao.LimparTexto(dados.Mensagem);
        if (mensagem is { Length: > 600 })
            return new ResultadoAcao(false, "A mensagem pode ter até 600 caracteres.");

        var canal = ContatoValidacao.LimparLinha(dados.Canal);
        if (canal.Length == 0) canal = "Outro";
        if (!LeadOpcoes.CanaisManuais.Contains(canal))
            return new ResultadoAcao(false, "Escolha como o contato chegou.");

        // Imóveis pelo código público (um ou mais)
        var codigos = (dados.Codigos ?? string.Empty)
            .Split(new[] { ' ', ',', ';', '\n', '\r', '\t' }, StringSplitOptions.RemoveEmptyEntries)
            .Select(c => CodigoImovelHelper.TentarNormalizar(c))
            .ToList();

        if (codigos.Any(c => c is null))
            return new ResultadoAcao(false, "Um dos códigos de imóvel não está no formato correto (5 caracteres).");

        var lista = codigos.Select(c => c!).Distinct().ToList();
        var imoveis = new List<Imovel>();

        if (lista.Count > 0)
        {
            imoveis = await _db.Imoveis.Include(i => i.Corretor)
                .Where(i => lista.Contains(i.Codigo) && i.DeletedAt == null)
                .ToListAsync(ct);

            // O Corretor só liga ao lead os imóveis dele
            if (!ehAdmin)
                imoveis = imoveis.Where(i => i.Corretor != null && i.Corretor.UsuarioId == usuarioId).ToList();

            var faltando = lista.Where(c => imoveis.All(i => i.Codigo != c)).ToList();
            if (faltando.Count > 0)
                return new ResultadoAcao(false, "Imóvel não encontrado: " + string.Join(", ", faltando) + ".");

            imoveis = lista.Select(c => imoveis.First(i => i.Codigo == c)).ToList();
        }

        // Atribuição: o Corretor que cadastra fica com o lead; o Administrador escolhe ou vale o corretor do imóvel
        int? corretorId;
        if (!ehAdmin)
        {
            corretorId = await _db.Corretores
                .Where(c => c.UsuarioId == usuarioId && c.Ativo)
                .Select(c => (int?)c.Id)
                .FirstOrDefaultAsync(ct);
        }
        else if (dados.CorretorId is { } escolhido)
        {
            var ok = await _db.Corretores.AnyAsync(c => c.Id == escolhido && c.Ativo && c.Usuario.Ativo, ct);
            if (!ok) return new ResultadoAcao(false, "Corretor não encontrado ou inativo.");
            corretorId = escolhido;
        }
        else
        {
            corretorId = LeadCriador.CorretorDosImoveis(imoveis);
        }

        var lead = await LeadCriador.CriarAsync(_db, nome, digitos, mensagem, OrigemLead.Manual, canal, imoveis, corretorId, null,
            usuarioId, $"Lead cadastrado manualmente ({canal.ToLowerInvariant()}).", ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.LeadCriado,
            $"Lead #{lead.Id} cadastrado manualmente.", lead.ImovelId, ct);

        return new ResultadoAcao(true, "Lead cadastrado.");
    }

    // ---------- Imóveis do lead ----------
    public async Task<ResultadoAcao> AdicionarImovelAsync(int id, string? codigo, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var normal = CodigoImovelHelper.TentarNormalizar(codigo);
        if (normal is null)
            return new ResultadoAcao(false, "Informe o código do imóvel (5 caracteres).");

        var lead = await Escopo(ehAdmin, usuarioId).Include(l => l.Imoveis).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NaoEncontrado;

        var imovel = await _db.Imoveis.Include(i => i.Corretor).FirstOrDefaultAsync(i => i.Codigo == normal && i.DeletedAt == null, ct);
        if (imovel is null || (!ehAdmin && !(imovel.Corretor != null && imovel.Corretor.UsuarioId == usuarioId)))
            return new ResultadoAcao(false, "Imóvel não encontrado.");

        if (lead.Imoveis.Any(li => li.ImovelId == imovel.Id))
            return new ResultadoAcao(true, "Este imóvel já está ligado ao lead.");

        lead.Imoveis.Add(new LeadImovel { ImovelId = imovel.Id });
        lead.ImovelId ??= imovel.Id;
        lead.TipoNegocio ??= LeadCriador.TipoDoImovel(imovel);

        _db.Interacoes.Add(new Interacao
        {
            LeadId = lead.Id, UsuarioId = usuarioId, Tipo = TipoInteracao.Nota,
            Descricao = $"Imóvel {imovel.Codigo} ligado ao lead.", DataHora = DateTime.Now
        });
        await _db.SaveChangesAsync(ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.LeadImovelAlterado,
            $"Lead #{lead.Id}: imóvel {imovel.Codigo} adicionado.", imovel.Id, ct);

        return new ResultadoAcao(true, $"O imóvel {imovel.Codigo} foi ligado ao lead.");
    }

    public async Task<ResultadoAcao> RemoverImovelAsync(int id, int imovelId, bool ehAdmin, int usuarioId, CancellationToken ct = default)
    {
        var lead = await Escopo(ehAdmin, usuarioId).Include(l => l.Imoveis).ThenInclude(li => li.Imovel)
            .FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NaoEncontrado;

        var ligacao = lead.Imoveis.FirstOrDefault(li => li.ImovelId == imovelId);
        if (ligacao is null) return new ResultadoAcao(false, "Este imóvel não está ligado ao lead.");

        var codigo = ligacao.Imovel.Codigo;
        _db.LeadImoveis.Remove(ligacao);

        // O principal é sempre um dos imóveis ligados
        if (lead.ImovelId == imovelId)
            lead.ImovelId = lead.Imoveis.Where(li => li.ImovelId != imovelId).Select(li => (int?)li.ImovelId).FirstOrDefault();

        _db.Interacoes.Add(new Interacao
        {
            LeadId = lead.Id, UsuarioId = usuarioId, Tipo = TipoInteracao.Nota,
            Descricao = $"Imóvel {codigo} retirado do lead.", DataHora = DateTime.Now
        });
        await _db.SaveChangesAsync(ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.LeadImovelAlterado,
            $"Lead #{lead.Id}: imóvel {codigo} retirado.", imovelId, ct);

        return new ResultadoAcao(true, $"O imóvel {codigo} foi retirado do lead.");
    }

    // ---------- Reatribuir e excluir (Administrador) ----------
    public async Task<ResultadoAcao> ReatribuirAsync(int id, int? corretorId, int usuarioId, CancellationToken ct = default)
    {
        var lead = await _db.Leads.Include(l => l.Corretor).FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NaoEncontrado;

        string? novoNome = null;
        if (corretorId is { } cid)
        {
            var novo = await _db.Corretores
                .AsNoTracking()
                .Where(c => c.Id == cid && c.Ativo && c.Usuario.Ativo)
                .Select(c => new { c.Nome })
                .FirstOrDefaultAsync(ct);

            if (novo is null)
                return new ResultadoAcao(false, "Corretor não encontrado ou inativo.");

            novoNome = novo.Nome;
        }

        if (lead.CorretorId == corretorId)
            return new ResultadoAcao(true, "O responsável continua o mesmo.");

        var anteriorNome = lead.Corretor?.Nome;
        lead.CorretorId = corretorId;

        _db.Interacoes.Add(new Interacao
        {
            LeadId = lead.Id,
            UsuarioId = usuarioId,
            Tipo = TipoInteracao.Nota,
            Descricao = $"Responsável alterado de {anteriorNome ?? "sem responsável"} para {novoNome ?? "sem responsável"}.",
            DataHora = DateTime.Now
        });

        await _db.SaveChangesAsync(ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.LeadReatribuido,
            $"Lead #{lead.Id}: de {anteriorNome ?? "sem responsável"} para {novoNome ?? "sem responsável"}.", lead.ImovelId, ct);

        return new ResultadoAcao(true, novoNome is null
            ? "O lead ficou sem responsável e voltou para a fila do administrador."
            : $"O lead agora é de {novoNome}.");
    }

    public async Task<ResultadoAcao> ExcluirAsync(int id, int usuarioId, CancellationToken ct = default)
    {
        var lead = await _db.Leads.FirstOrDefaultAsync(l => l.Id == id, ct);
        if (lead is null) return NaoEncontrado;

        var imovelId = lead.ImovelId;
        var origem = lead.Origem;

        // Imóveis ligados, interações e visitas do lead saem junto (CASCADE no banco)
        _db.Leads.Remove(lead);
        await _db.SaveChangesAsync(ct);

        await _historico.RegistrarAsync(usuarioId, HistoricoAcoes.LeadExcluido,
            $"Lead #{id} excluído permanentemente (origem: {LeadTexto.NomeOrigem(origem)}).", imovelId, ct);

        _logger.LogInformation("Lead {LeadId} excluído permanentemente (usuário {UsuarioId}).", id, usuarioId);

        return new ResultadoAcao(true, "O lead e os seus registros foram excluídos permanentemente.");
    }
}
