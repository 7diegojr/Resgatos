namespace BetelImoveis.Models.ViewModels;

/// <summary>Dados do campo de seleção personalizado do painel (partial _Seletor, comportamento em combo.js).</summary>
public class SeletorViewModel
{
    /// <summary>Nome do campo enviado no formulário (e base do id do botão).</summary>
    public string Nome { get; set; } = string.Empty;

    /// <summary>Id do botão do seletor. Vazio = "sel-" + Nome. Informe quando a mesma página tem dois seletores com o mesmo nome (ids repetidos).</summary>
    public string? Id { get; set; }

    /// <summary>Texto lido por leitores de tela.</summary>
    public string Rotulo { get; set; } = string.Empty;

    /// <summary>Valor escolhido. Vazio = a primeira opção (a que representa "todos").</summary>
    public string Valor { get; set; } = string.Empty;

    public List<SeletorOpcao> Opcoes { get; set; } = new();

    /// <summary>Campo menor, para o "Ordenar por".</summary>
    public bool Compacto { get; set; }

    /// <summary>Realça o campo quando há um filtro escolhido (valor diferente de vazio).</summary>
    public bool DestacarFiltro { get; set; }
}

public record SeletorOpcao(string Valor, string Rotulo);

/// <summary>Dados de um grupo de opções em "pílulas" do modal de filtros do painel (partial _FiltroPills).</summary>
public class FiltroPillsViewModel
{
    /// <summary>Nome do campo enviado no formulário (campo oculto).</summary>
    public string Nome { get; set; } = string.Empty;

    public string Rotulo { get; set; } = string.Empty;

    /// <summary>Valor escolhido. Vazio = "Todos".</summary>
    public string Valor { get; set; } = string.Empty;

    /// <summary>Opções (a primeira, com valor vazio, é a que representa "Todos").</summary>
    public List<SeletorOpcao> Opcoes { get; set; } = new();

    /// <summary>Três opções por linha (usado no tipo de imóvel).</summary>
    public bool TresPorLinha { get; set; }

    /// <summary>true = o grupo não cria o campo oculto, porque o valor já pertence a outro campo da página (ex.: o Status da barra).</summary>
    public bool SemCampo { get; set; }
}

/// <summary>Faixa de preço com dois controles deslizantes (mínimo e máximo) do modal de filtros do painel (partial _FaixaPreco).</summary>
public class FaixaPrecoViewModel
{
    public string Rotulo { get; set; } = "Preço";
    public decimal? ValorMin { get; set; }
    public decimal? ValorMax { get; set; }

    /// <summary>Finalidade escolhida no filtro (venda | aluguel | ambos | vazio = todas). Define qual escala vale.</summary>
    public string Finalidade { get; set; } = string.Empty;

    /// <summary>Menor e maior preço por finalidade ("" = todas, "venda", "aluguel", "ambos").</summary>
    public Dictionary<string, FaixaLimites> Limites { get; set; } = new();
}
