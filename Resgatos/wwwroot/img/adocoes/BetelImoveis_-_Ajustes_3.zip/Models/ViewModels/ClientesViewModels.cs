namespace BetelImoveis.Models.ViewModels;

public class ClientesFiltro
{
    public const int TamanhoPagina = 10;

    public string? Busca { get; set; }      // nome ou telefone
    public string? Situacao { get; set; }   // ativos (padrão) | inativos | todos
    public string? Corretor { get; set; }   // só o Administrador: id do corretor
    public int Pagina { get; set; } = 1;

    public string? BuscaNormalizada => string.IsNullOrWhiteSpace(Busca) ? null : (Busca.Trim().Length > 100 ? Busca.Trim()[..100] : Busca.Trim());
    public int? CorretorId => int.TryParse(Corretor, out var id) && id > 0 ? id : null;

    public string SituacaoNormalizada => Situacao?.Trim().ToLowerInvariant() switch
    {
        "inativos" => "inativos",
        "todos" => "todos",
        _ => "ativos"
    };

    public bool TemFiltros => BuscaNormalizada is not null || CorretorId is not null || SituacaoNormalizada != "ativos";
}

public class ClienteLinha
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string Telefone { get; set; } = string.Empty;
    public bool Ativo { get; set; }
    public string? CorretorNome { get; set; }
    public int QtdImoveis { get; set; }
    public DateTime CreatedAt { get; set; }
}

public class ClientesViewModel
{
    public ClientesFiltro Filtro { get; set; } = new();
    public List<ClienteLinha> Clientes { get; set; } = new();
    public int Total { get; set; }
    public int PaginaAtual { get; set; } = 1;
    public int TotalPaginas { get; set; } = 1;
    public List<CorretorOpcao> Corretores { get; set; } = new();
}

/// <summary>Dados do cadastro manual de cliente: só o que aparece na tabela de clientes.</summary>
public class ClienteNovoViewModel
{
    public string? Nome { get; set; }
    public string? Telefone { get; set; }

    /// <summary>Códigos de imóvel digitados (separados por espaço, vírgula ou ponto e vírgula).</summary>
    public string? Codigos { get; set; }

    /// <summary>Só o Administrador escolhe; o Corretor fica como responsável pelos clientes que cadastra.</summary>
    public int? CorretorId { get; set; }
}

public class ClienteLeadItem
{
    public int Id { get; set; }
    public Enums.StatusLead Status { get; set; }
    public Enums.OrigemLead Origem { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? ImovelCodigo { get; set; }
}

public class ClienteFichaViewModel
{
    public int Id { get; set; }
    public string Nome { get; set; } = string.Empty;
    public string Telefone { get; set; } = string.Empty;
    public string? Observacoes { get; set; }
    public bool Ativo { get; set; }
    public string? CorretorNome { get; set; }
    public DateTime CreatedAt { get; set; }

    /// <summary>Imóveis de todos os leads do cliente (um ou mais).</summary>
    public List<LeadImovelItem> Imoveis { get; set; } = new();
    public List<ClienteLeadItem> Leads { get; set; } = new();
    public List<LeadVisitaItem> Visitas { get; set; } = new();

    /// <summary>Linha do tempo do cliente e dos leads dele, da mais recente para a mais antiga.</summary>
    public List<InteracaoItem> Interacoes { get; set; } = new();

    public string? WhatsappLink => BetelImoveis.Helpers.FormatHelper.WhatsappLink(Telefone);
}
