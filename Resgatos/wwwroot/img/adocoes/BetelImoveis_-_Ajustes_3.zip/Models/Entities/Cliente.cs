using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BetelImoveis.Models.Entities;

/// <summary>Pessoa que já avançou no funil: nasce da conversão de um lead (ao chegar em Proposta ou Fechado, ou pelo botão da ficha).</summary>
[Table("clientes")]
public class Cliente
{
    [Key]
    [Column("id")]
    public int Id { get; set; }

    [Required, MaxLength(150)]
    [Column("nome")]
    public string Nome { get; set; } = string.Empty;

    [Required, MaxLength(30)]
    [Column("telefone")]
    public string Telefone { get; set; } = string.Empty;

    [Required, MaxLength(20)]
    [Column("telefone_normalizado")]
    public string TelefoneNormalizado { get; set; } = string.Empty;

    [Column("observacoes", TypeName = "text")]
    public string? Observacoes { get; set; }

    [Column("corretor_responsavel_id")]
    public int? CorretorResponsavelId { get; set; }

    [Column("ativo")]
    public bool Ativo { get; set; } = true;

    /// <summary>
    /// true = cadastrado à mão. Esses clientes sempre aparecem na página Clientes. Os demais (criados ao fechar um negócio)
    /// só aparecem enquanto têm um lead na etapa Fechado.
    /// </summary>
    [Column("manual")]
    public bool Manual { get; set; }

    [Column("created_at")]
    public DateTime? CreatedAt { get; set; }

    [Column("updated_at")]
    public DateTime? UpdatedAt { get; set; }

    public Corretor? CorretorResponsavel { get; set; }

    public ICollection<Lead> Leads { get; set; } = new List<Lead>();
    public ICollection<ClienteImovel> Imoveis { get; set; } = new List<ClienteImovel>();
    public ICollection<Interacao> Interacoes { get; set; } = new List<Interacao>();
}
