using System.ComponentModel.DataAnnotations.Schema;

namespace BetelImoveis.Models.Entities;

/// <summary>Imóvel ligado diretamente a um cliente (usado no cadastro manual). Os imóveis dos leads do cliente também contam.</summary>
[Table("cliente_imoveis")]
public class ClienteImovel
{
    [Column("cliente_id")]
    public int ClienteId { get; set; }

    [Column("imovel_id")]
    public int ImovelId { get; set; }

    [Column("created_at")]
    public DateTime? CreatedAt { get; set; }

    public Cliente Cliente { get; set; } = null!;
    public Imovel Imovel { get; set; } = null!;
}
