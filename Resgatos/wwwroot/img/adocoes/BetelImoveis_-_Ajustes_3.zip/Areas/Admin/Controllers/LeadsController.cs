using BetelImoveis.Constants;
using BetelImoveis.Helpers;
using BetelImoveis.Models.Enums;
using BetelImoveis.Models.ViewModels;
using BetelImoveis.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BetelImoveis.Areas.Admin.Controllers;

/// <summary>
/// Painel de leads (funil de vendas). Administrador: todos os leads, reatribui e exclui definitivamente. Corretor: só os leads
/// ligados a ele (o service filtra no servidor; para os demais a resposta é "não encontrado").
/// </summary>
[Area("Admin")]
[Authorize(Roles = Perfis.Todos)]
public class LeadsController : Controller
{
    private readonly ILeadPainelService _leads;

    public LeadsController(ILeadPainelService leads) => _leads = leads;

    private bool EhAdmin => User.IsInRole(Perfis.Administrador);

    // GET /admin/leads?busca=...&status=novo&origem=imovel&corretor=3&de=2026-10-01&visao=lista&pagina=2
    public async Task<IActionResult> Index([FromQuery] LeadsFiltro filtro, CancellationToken ct)
    {
        // O filtro por corretor só existe para o Administrador
        if (!EhAdmin) filtro.Corretor = null;

        // O quadro (kanban) é a visão padrão; visao=lista mostra a tabela
        var modelo = filtro.ModoQuadro
            ? await _leads.ListarQuadroAsync(filtro, EhAdmin, User.UsuarioId(), ct)
            : await _leads.ListarAsync(filtro, EhAdmin, User.UsuarioId(), ct);

        return View(modelo);
    }

    // GET /admin/leads/5 — ficha do lead
    [HttpGet("admin/leads/{id:int}")]
    public async Task<IActionResult> Detalhes(int id, CancellationToken ct)
    {
        var ficha = await _leads.ObterFichaAsync(id, EhAdmin, User.UsuarioId(), ct);
        return ficha is null ? NotFound() : View(ficha);
    }

    // GET /admin/leads/avisos — conteúdo do sino (a página atualiza o sino de tempos em tempos)
    [HttpGet("admin/leads/avisos")]
    public IActionResult Avisos() => ViewComponent("Avisos");

    // GET /admin/leads/dadosfechamento/5 — imóveis do lead para a janela "Fechar negócio" (JSON)
    [HttpGet("admin/leads/dadosfechamento/{id:int}")]
    public async Task<IActionResult> DadosFechamento(int id, CancellationToken ct)
    {
        var ficha = await _leads.ObterFichaAsync(id, EhAdmin, User.UsuarioId(), ct);
        if (ficha is null) return NotFound();

        return Json(new
        {
            id = ficha.Id,
            nome = ficha.Nome,
            tipo = ficha.TipoNegocio?.ToString().ToLowerInvariant(),
            imoveis = ficha.Imoveis.Where(i => !i.NaLixeira).Select(i => new
            {
                id = i.Id,
                codigo = i.Codigo,
                titulo = i.Titulo,
                principal = i.Principal,
                finalidade = i.Finalidade.ToString().ToLowerInvariant(),
                precoVenda = i.PrecoVenda is { } v ? NumeroBr.Formatar(v) : null,
                precoAluguel = i.PrecoAluguel is { } a ? NumeroBr.Formatar(a) : null,
                status = i.Status.ToString().ToLowerInvariant()
            })
        });
    }

    // ---------- Ações (CSRF validado globalmente). Voltam para a página de onde saíram. ----------

    [HttpPost]
    public async Task<IActionResult> Cadastrar(LeadNovoViewModel dados, string? returnUrl, CancellationToken ct)
    {
        var resultado = await _leads.CriarManualAsync(dados, EhAdmin, User.UsuarioId(), ct);
        TempData[resultado.Sucesso ? "Sucesso" : "Erro"] = resultado.Mensagem;

        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? LocalRedirect(returnUrl)
            : RedirectToAction(nameof(Index), new { area = "Admin" });
    }

    [HttpPost]
    public async Task<IActionResult> AlterarEtapa(int id, StatusLead? etapa, string? returnUrl, CancellationToken ct)
    {
        if (etapa is null)
            return Voltar(new ResultadoAcao(false, "Escolha uma etapa válida."), id, returnUrl);

        return Voltar(await _leads.AlterarEtapaAsync(id, etapa.Value, EhAdmin, User.UsuarioId(), ct), id, returnUrl);
    }

    [HttpPost]
    public async Task<IActionResult> Fechar(LeadFechamentoViewModel dados, string? returnUrl, CancellationToken ct)
        => Voltar(await _leads.FecharAsync(dados, EhAdmin, User.UsuarioId(), ct), dados.Id, returnUrl);

    [HttpPost]
    public async Task<IActionResult> MarcarComoPerdido(int id, MotivoPerda? motivo, string? observacao, string? returnUrl, CancellationToken ct)
    {
        if (motivo is null)
            return Voltar(new ResultadoAcao(false, "Informe o motivo da perda."), id, returnUrl);

        return Voltar(await _leads.MarcarComoPerdidoAsync(id, motivo.Value, observacao, EhAdmin, User.UsuarioId(), ct), id, returnUrl);
    }

    [HttpPost]
    public async Task<IActionResult> AdicionarInteracao(int id, TipoInteracao? tipo, string? descricao, string? returnUrl, CancellationToken ct)
    {
        if (tipo is null)
            return Voltar(new ResultadoAcao(false, "Escolha um tipo de registro válido."), id, returnUrl);

        return Voltar(await _leads.AdicionarInteracaoAsync(id, tipo.Value, descricao, EhAdmin, User.UsuarioId(), ct), id, returnUrl);
    }

    [HttpPost]
    public async Task<IActionResult> AdicionarImovel(int id, string? codigo, string? returnUrl, CancellationToken ct)
        => Voltar(await _leads.AdicionarImovelAsync(id, codigo, EhAdmin, User.UsuarioId(), ct), id, returnUrl);

    [HttpPost]
    public async Task<IActionResult> RemoverImovel(int id, int imovelId, string? returnUrl, CancellationToken ct)
        => Voltar(await _leads.RemoverImovelAsync(id, imovelId, EhAdmin, User.UsuarioId(), ct), id, returnUrl);

    // Chamado pelo quadro (arrastar e soltar) via fetch. O token CSRF vai no cabeçalho "RequestVerificationToken" e é
    // validado globalmente. Responde JSON; a permissão é a mesma das demais ações (lead de outro corretor = não encontrado).
    [HttpPost]
    public async Task<IActionResult> MoverEtapa(int id, StatusLead? etapa, CancellationToken ct)
    {
        if (etapa is null)
            return BadRequest(new { sucesso = false, mensagem = "Escolha uma etapa válida." });

        var resultado = await _leads.AlterarEtapaAsync(id, etapa.Value, EhAdmin, User.UsuarioId(), ct);

        return resultado.Sucesso
            ? Ok(new { sucesso = true, mensagem = resultado.Mensagem })
            : BadRequest(new { sucesso = false, mensagem = resultado.Mensagem });
    }

    // Só o Administrador reatribui e exclui definitivamente (o [Authorize] barra o Corretor no servidor)
    [HttpPost]
    [Authorize(Roles = Perfis.Administrador)]
    public async Task<IActionResult> Reatribuir(int id, int? corretorId, string? returnUrl, CancellationToken ct)
        => Voltar(await _leads.ReatribuirAsync(id, corretorId, User.UsuarioId(), ct), id, returnUrl);

    [HttpPost]
    [Authorize(Roles = Perfis.Administrador)]
    public async Task<IActionResult> Excluir(int id, string? returnUrl, CancellationToken ct)
    {
        var resultado = await _leads.ExcluirAsync(id, User.UsuarioId(), ct);

        // Depois de excluir, a ficha deixa de existir: volta para a lista (ou para o endereço local informado)
        TempData[resultado.Sucesso ? "Sucesso" : "Erro"] = resultado.Mensagem;

        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl) && !returnUrl.Contains($"/admin/leads/{id}", StringComparison.OrdinalIgnoreCase)
            ? LocalRedirect(returnUrl)
            : RedirectToAction(nameof(Index), new { area = "Admin" });
    }

    // Mostra a mensagem e volta para a página de origem (só aceita endereço do próprio site). Sem endereço, abre a ficha.
    // A área é informada de propósito: o site público tem controllers com o mesmo nome.
    private IActionResult Voltar(ResultadoAcao resultado, int id, string? returnUrl)
    {
        TempData[resultado.Sucesso ? "Sucesso" : "Erro"] = resultado.Mensagem;

        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? LocalRedirect(returnUrl)
            : RedirectToAction(nameof(Detalhes), new { area = "Admin", id });
    }
}
