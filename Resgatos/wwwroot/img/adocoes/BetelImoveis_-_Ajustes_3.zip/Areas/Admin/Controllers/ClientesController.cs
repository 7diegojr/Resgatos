using BetelImoveis.Constants;
using BetelImoveis.Helpers;
using BetelImoveis.Models.Enums;
using BetelImoveis.Models.ViewModels;
using BetelImoveis.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BetelImoveis.Areas.Admin.Controllers;

/// <summary>
/// Clientes (leads que avançaram no funil). Administrador: todos. Corretor: os clientes de que é responsável e os que têm
/// lead dele (o service filtra no servidor; para os demais a resposta é "não encontrado").
/// </summary>
[Area("Admin")]
[Authorize(Roles = Perfis.Todos)]
public class ClientesController : Controller
{
    private readonly IClienteService _clientes;

    public ClientesController(IClienteService clientes) => _clientes = clientes;

    private bool EhAdmin => User.IsInRole(Perfis.Administrador);

    // GET /admin/clientes?busca=...&situacao=ativos&corretor=3&pagina=2
    public async Task<IActionResult> Index([FromQuery] ClientesFiltro filtro, CancellationToken ct)
    {
        // O filtro por corretor só existe para o Administrador
        if (!EhAdmin) filtro.Corretor = null;

        return View(await _clientes.ListarAsync(filtro, EhAdmin, User.UsuarioId(), ct));
    }

    // GET /admin/clientes/5 — ficha do cliente
    [HttpGet("admin/clientes/{id:int}")]
    public async Task<IActionResult> Detalhes(int id, CancellationToken ct)
    {
        var ficha = await _clientes.ObterFichaAsync(id, EhAdmin, User.UsuarioId(), ct);
        return ficha is null ? NotFound() : View(ficha);
    }

    // POST /admin/clientes/cadastrar — cadastro manual (nome, telefone, imóveis e responsável)
    [HttpPost]
    public async Task<IActionResult> Cadastrar(ClienteNovoViewModel dados, string? returnUrl, CancellationToken ct)
    {
        var resultado = await _clientes.CriarManualAsync(dados, EhAdmin, User.UsuarioId(), ct);
        TempData[resultado.Sucesso ? "Sucesso" : "Erro"] = resultado.Mensagem;

        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? LocalRedirect(returnUrl)
            : RedirectToAction(nameof(Index), new { area = "Admin" });
    }

    // POST /admin/clientes/adicionarinteracao — ligação, WhatsApp, proposta ou anotação na linha do tempo
    [HttpPost]
    public async Task<IActionResult> AdicionarInteracao(int id, TipoInteracao? tipo, string? descricao, string? returnUrl, CancellationToken ct)
    {
        var resultado = tipo is null
            ? new ResultadoAcao(false, "Escolha um tipo de registro válido.")
            : await _clientes.AdicionarInteracaoAsync(id, tipo.Value, descricao, EhAdmin, User.UsuarioId(), ct);

        TempData[resultado.Sucesso ? "Sucesso" : "Erro"] = resultado.Mensagem;

        return !string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl)
            ? LocalRedirect(returnUrl)
            : RedirectToAction(nameof(Detalhes), new { area = "Admin", id });
    }
}
