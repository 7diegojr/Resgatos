-- ==========================================================================
-- Betel Imóveis — Leads, funil de vendas, clientes, interações e visitas
-- (MySQL / MariaDB) Script OPCIONAL e idempotente.
--
-- O sistema já faz tudo isto sozinho ao iniciar (DbInicializador.AtualizarLeadsAsync).
-- Use este arquivo só se preferir aplicar a estrutura manualmente no banco.
-- ==========================================================================

-- Data de fechamento do imóvel (usada pelos relatórios no lugar do updated_at).
-- Se a coluna já existir, o MySQL avisa que ela é duplicada: pode ignorar o aviso.
ALTER TABLE imoveis ADD COLUMN data_fechamento DATETIME(6) NULL;

-- Imóveis que já estavam como Vendido ou Alugado: usam a data da última alteração como data de fechamento
UPDATE imoveis SET data_fechamento = updated_at
 WHERE status IN ('VENDIDO', 'ALUGADO') AND data_fechamento IS NULL;

CREATE TABLE IF NOT EXISTS clientes (
    id INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(150) NOT NULL,
    telefone VARCHAR(30) NOT NULL,
    telefone_normalizado VARCHAR(20) NOT NULL,
    observacoes TEXT NULL,
    corretor_responsavel_id INT NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    manual TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME(6) NULL,
    updated_at DATETIME(6) NULL,
    PRIMARY KEY (id),
    INDEX IX_clientes_telefone_normalizado (telefone_normalizado),
    CONSTRAINT fk_clientes_corretor FOREIGN KEY (corretor_responsavel_id) REFERENCES corretores (id) ON DELETE SET NULL
) CHARACTER SET utf8mb4;

CREATE TABLE IF NOT EXISTS leads (
    id INT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(150) NOT NULL,
    telefone VARCHAR(30) NOT NULL,
    telefone_normalizado VARCHAR(20) NOT NULL,
    mensagem TEXT NULL,
    origem VARCHAR(20) NOT NULL,
    assunto VARCHAR(200) NULL,
    imovel_id INT NULL,
    corretor_id INT NULL,
    cliente_id INT NULL,
    status VARCHAR(20) NOT NULL,
    motivo_perda VARCHAR(30) NULL,
    observacao_perda VARCHAR(200) NULL,
    tipo_negocio VARCHAR(20) NULL,
    valor_negocio DECIMAL(15,2) NULL,
    primeiro_atendimento_em DATETIME(6) NULL,
    etapa_alterada_em DATETIME(6) NULL,
    encerrado_em DATETIME(6) NULL,
    created_at DATETIME(6) NULL,
    updated_at DATETIME(6) NULL,
    PRIMARY KEY (id),
    INDEX IX_leads_status (status),
    INDEX IX_leads_corretor_id (corretor_id),
    INDEX IX_leads_created_at (created_at),
    INDEX IX_leads_telefone_normalizado (telefone_normalizado),
    CONSTRAINT fk_leads_imovel FOREIGN KEY (imovel_id) REFERENCES imoveis (id) ON DELETE SET NULL,
    CONSTRAINT fk_leads_corretor FOREIGN KEY (corretor_id) REFERENCES corretores (id) ON DELETE SET NULL,
    CONSTRAINT fk_leads_cliente FOREIGN KEY (cliente_id) REFERENCES clientes (id) ON DELETE SET NULL
) CHARACTER SET utf8mb4;

CREATE TABLE IF NOT EXISTS lead_imoveis (
    lead_id INT NOT NULL,
    imovel_id INT NOT NULL,
    created_at DATETIME(6) NULL,
    PRIMARY KEY (lead_id, imovel_id),
    CONSTRAINT fk_lead_imoveis_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
    CONSTRAINT fk_lead_imoveis_imovel FOREIGN KEY (imovel_id) REFERENCES imoveis (id) ON DELETE CASCADE
) CHARACTER SET utf8mb4;

CREATE TABLE IF NOT EXISTS cliente_imoveis (
    cliente_id INT NOT NULL,
    imovel_id INT NOT NULL,
    created_at DATETIME(6) NULL,
    PRIMARY KEY (cliente_id, imovel_id),
    CONSTRAINT fk_cliente_imoveis_cliente FOREIGN KEY (cliente_id) REFERENCES clientes (id) ON DELETE CASCADE,
    CONSTRAINT fk_cliente_imoveis_imovel FOREIGN KEY (imovel_id) REFERENCES imoveis (id) ON DELETE CASCADE
) CHARACTER SET utf8mb4;

CREATE TABLE IF NOT EXISTS interacoes (
    id INT NOT NULL AUTO_INCREMENT,
    lead_id INT NULL,
    cliente_id INT NULL,
    usuario_id INT NULL,
    tipo VARCHAR(20) NOT NULL,
    descricao TEXT NOT NULL,
    data_hora DATETIME(6) NOT NULL,
    PRIMARY KEY (id),
    INDEX IX_interacoes_lead_id (lead_id),
    INDEX IX_interacoes_cliente_id (cliente_id),
    CONSTRAINT fk_interacoes_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
    CONSTRAINT fk_interacoes_cliente FOREIGN KEY (cliente_id) REFERENCES clientes (id) ON DELETE CASCADE,
    CONSTRAINT fk_interacoes_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL
) CHARACTER SET utf8mb4;

CREATE TABLE IF NOT EXISTS visitas (
    id INT NOT NULL AUTO_INCREMENT,
    lead_id INT NOT NULL,
    imovel_id INT NULL,
    corretor_id INT NULL,
    data_hora DATETIME(6) NOT NULL,
    status VARCHAR(20) NOT NULL,
    observacoes TEXT NULL,
    interesse VARCHAR(20) NULL,
    feedback_observacao TEXT NULL,
    feedback_em DATETIME(6) NULL,
    created_at DATETIME(6) NULL,
    PRIMARY KEY (id),
    INDEX IX_visitas_data_hora (data_hora),
    CONSTRAINT fk_visitas_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE,
    CONSTRAINT fk_visitas_imovel FOREIGN KEY (imovel_id) REFERENCES imoveis (id) ON DELETE SET NULL,
    CONSTRAINT fk_visitas_corretor FOREIGN KEY (corretor_id) REFERENCES corretores (id) ON DELETE SET NULL
) CHARACTER SET utf8mb4;

-- Só para bancos que já tinham a tabela clientes de uma versão anterior (cadastro manual de clientes).
-- Em banco novo a coluna já existe e o MySQL avisa que ela é duplicada: pode ignorar o aviso.
ALTER TABLE clientes ADD COLUMN manual TINYINT(1) NOT NULL DEFAULT 0;
