// Betel Imóveis — Admin › Leads: janela "Fechar negócio".
// Ao abrir a janela (admin-imoveis.js já a abriu e preencheu o id do lead), busca os imóveis do lead no servidor
// (GET /admin/leads/dadosfechamento/{id}), sugere o tipo e o valor e oferece mudar o imóvel para Vendido ou Alugado.
// Quem decide tudo é o servidor: aqui só se monta o formulário.
(function () {
    "use strict";

    var modal = document.getElementById("modal-fechar");
    if (!modal) return;

    var form = modal.querySelector("form");
    var urlBase = form.getAttribute("data-url-dados");           // .../dadosfechamento/0
    var carregando = modal.querySelector("[data-fechar-carregando]");
    var blocoImovel = modal.querySelector("[data-fechar-imovel]");
    // Campos de seleção do projeto (combo.js): cada um tem um campo oculto com o valor escolhido
    var comboImovel = blocoImovel.querySelector("[data-seletor]");
    var valorImovel = comboImovel.querySelector('input[type="hidden"]');
    var comboTipo = modal.querySelector("[data-fechar-tipo] [data-seletor]");
    var valorTipo = comboTipo.querySelector('input[type="hidden"]');
    var campoValor = form.querySelector('input[name="valor"]');
    var blocoAtualizar = modal.querySelector("[data-fechar-atualizar]");
    var textoAtualizar = modal.querySelector("[data-fechar-atualizar-texto]");
    var caixaAtualizar = form.querySelector('input[name="atualizarImovel"]');

    var imoveis = [];
    var valorEditado = false;

    function definirTipo(valor) {
        if (valorTipo.value === valor) return;   // evita um ciclo: escolher dispara "combo:change", que chama sugerir()
        comboTipo.dispatchEvent(new CustomEvent("combo:definir", { detail: { valor: valor } }));
    }

    function atual() {
        var id = parseInt(valorImovel.value, 10);
        return imoveis.filter(function (i) { return i.id === id; })[0] || null;
    }

    function sugerir() {
        var im = atual();
        var tipo = valorTipo.value;

        if (im) {
            // Imóvel de uma finalidade só: o tipo já está definido
            if (im.finalidade === "venda" || im.finalidade === "aluguel") definirTipo(im.finalidade);
            tipo = valorTipo.value;

            if (!valorEditado) {
                var preco = tipo === "aluguel" ? im.precoAluguel : im.precoVenda;
                campoValor.value = preco || "";
            }

            if (blocoAtualizar) {
                var novo = tipo === "aluguel" ? "Alugado" : (tipo === "venda" ? "Vendido" : "Vendido ou Alugado");
                textoAtualizar.textContent = "Marcar o imóvel " + im.codigo + " como " + novo;
                blocoAtualizar.hidden = false;
            }
        } else if (blocoAtualizar) {
            blocoAtualizar.hidden = true;
            caixaAtualizar.checked = false;
        }
    }

    function preencher(dados) {
        imoveis = dados.imoveis || [];

        var principal = imoveis.filter(function (i) { return i.principal; })[0];
        comboImovel.dispatchEvent(new CustomEvent("combo:opcoes", {
            detail: {
                opcoes: imoveis.length === 0
                    ? [{ valor: "", rotulo: "Sem imóvel" }]
                    : imoveis.map(function (i) { return { valor: String(i.id), rotulo: i.codigo + " · " + i.titulo }; }),
                valor: principal ? String(principal.id) : ""
            }
        }));

        blocoImovel.hidden = imoveis.length <= 1;
        if (carregando) carregando.hidden = true;

        definirTipo(dados.tipo === "venda" || dados.tipo === "aluguel" ? dados.tipo : "");
        campoValor.value = "";
        valorEditado = false;
        caixaAtualizar.checked = true;
        sugerir();
    }

    function carregar(id) {
        if (carregando) { carregando.hidden = false; carregando.textContent = "Carregando os imóveis do lead…"; }
        blocoImovel.hidden = true;
        if (blocoAtualizar) blocoAtualizar.hidden = true;
        definirTipo("");
        valorImovel.value = "";
        campoValor.value = "";
        valorEditado = false;
        imoveis = [];

        fetch(urlBase.replace(/\/0(\?.*)?$/, "/" + encodeURIComponent(id)), {
            credentials: "same-origin",
            headers: { "X-Requested-With": "XMLHttpRequest", "Accept": "application/json" }
        })
            .then(function (r) { return r.ok ? r.json() : Promise.reject(); })
            .then(preencher)
            .catch(function () {
                if (carregando) carregando.textContent = "Não foi possível carregar os imóveis. Você ainda pode informar o tipo e o valor.";
            });
    }

    // admin-imoveis.js (carregado antes) abre a janela no mesmo clique; aqui só carregamos os dados do lead
    document.querySelectorAll('[data-modal-open="fechar"]').forEach(function (botao) {
        botao.addEventListener("click", function () {
            var id = botao.getAttribute("data-id");
            if (id) carregar(id);
        });
    });

    comboImovel.addEventListener("combo:change", function () { valorEditado = false; sugerir(); });
    comboTipo.addEventListener("combo:change", function () { valorEditado = false; sugerir(); });
    campoValor.addEventListener("input", function () { valorEditado = true; });
})();
