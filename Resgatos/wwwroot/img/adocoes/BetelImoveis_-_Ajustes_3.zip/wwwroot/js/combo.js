// Betel Imóveis — campos de seleção personalizados (Home e páginas Comprar/Alugar)
//  • Combo com pesquisa: Cidade e Bairro (opções de /api/localidades). Só vale o que for ESCOLHIDO na lista.
//    Bairro sem cidade escolhida mostra apenas "Nenhum bairro encontrado".
//  • Seletor simples: Tipo de imóvel (lista fixa, no mesmo visual).
// Quando a escolha muda, o campo dispara o evento "combo:change" (usado pelo Bairro, pela listagem e pelos formulários).
// Para escolher uma opção por código, a página envia ao seletor o evento "combo:definir":
//   seletor.dispatchEvent(new CustomEvent("combo:definir", { detail: { valor: "Vender" } }));
(function () {
    "use strict";

    var combos = {};

    // ==========================================================================
    // Combo com pesquisa
    // ==========================================================================
    function iniciarCombo(el) {
        var nome = el.getAttribute("data-combo");
        var url = el.getAttribute("data-url");
        var dependeDe = el.getAttribute("data-depende");
        var textoVazio = el.getAttribute("data-vazio") || "Nenhum resultado encontrado";
        var input = el.querySelector(".combo__input");
        var oculto = el.querySelector("input[type=hidden]");
        var lista = el.querySelector(".combo__lista");
        var limpar = el.querySelector(".combo__limpar");

        var confirmado = oculto.value;   // última opção realmente escolhida
        var opcoes = [];
        var ativo = -1;
        var requisicao = null;
        var temporizador = null;

        combos[nome] = { el: el, oculto: oculto };

        // Estado inicial (ex.: página já aberta com ?cidade=Bauru)
        if (confirmado) {
            input.value = confirmado;
            limpar.hidden = false;
        }

        function valorPai() {
            return dependeDe && combos[dependeDe] ? combos[dependeDe].oculto.value : "";
        }

        function aberta() { return !lista.hidden; }

        function fechar() {
            lista.hidden = true;
            input.setAttribute("aria-expanded", "false");
            input.removeAttribute("aria-activedescendant");
            ativo = -1;
        }

        function destacar(indice) {
            var itens = lista.querySelectorAll(".combo__opcao");
            itens.forEach(function (li, n) { li.classList.toggle("is-active", n === indice); });
            ativo = indice;
            if (indice >= 0 && itens[indice]) {
                input.setAttribute("aria-activedescendant", itens[indice].id);
                itens[indice].scrollIntoView({ block: "nearest" });
            } else {
                input.removeAttribute("aria-activedescendant");
            }
        }

        function desenhar() {
            lista.innerHTML = "";
            if (opcoes.length === 0) {
                var vazio = document.createElement("li");
                vazio.className = "combo__vazio";
                vazio.textContent = textoVazio;
                lista.appendChild(vazio);
            } else {
                opcoes.forEach(function (texto, n) {
                    var li = document.createElement("li");
                    li.className = "combo__opcao" + (texto === confirmado ? " is-selected" : "");
                    li.id = input.id + "-opcao-" + n;
                    li.setAttribute("role", "option");
                    li.textContent = texto;
                    // mousedown (e não click) para o campo não perder o foco antes da escolha
                    li.addEventListener("mousedown", function (e) { e.preventDefault(); selecionar(texto); });
                    lista.appendChild(li);
                });
            }
            lista.hidden = false;
            input.setAttribute("aria-expanded", "true");
            destacar(-1);
        }

        function buscar() {
            if (requisicao) requisicao.abort();

            // Bairro sem cidade escolhida: não há o que listar
            if (dependeDe && valorPai() === "") {
                opcoes = [];
                desenhar();
                return;
            }

            requisicao = new AbortController();

            // Texto igual à escolha atual (ou vazio): mostra a lista completa; senão filtra pelo que foi digitado
            var digitado = input.value.trim();
            var params = new URLSearchParams();
            if (digitado && digitado !== confirmado) params.set("q", digitado);
            if (dependeDe) params.set("cidade", valorPai());

            fetch(url + "?" + params.toString(), { signal: requisicao.signal, headers: { Accept: "application/json" } })
                .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
                .then(function (dados) { opcoes = Array.isArray(dados) ? dados : []; desenhar(); })
                .catch(function (erro) {
                    if (erro && erro.name === "AbortError") return;
                    opcoes = [];
                    desenhar();
                });
        }

        function avisarMudanca() {
            el.dispatchEvent(new CustomEvent("combo:change", { bubbles: true }));
        }

        function selecionar(texto) {
            var mudou = oculto.value !== texto;
            oculto.value = texto;
            confirmado = texto;
            input.value = texto;
            limpar.hidden = false;
            fechar();
            if (mudou) avisarMudanca();
        }

        function zerar(silencioso) {
            var tinha = oculto.value !== "";
            oculto.value = "";
            confirmado = "";
            input.value = "";
            limpar.hidden = true;
            fechar();
            if (tinha && !silencioso) avisarMudanca();
        }

        // ----- Eventos do campo -----
        input.addEventListener("input", function () {
            limpar.hidden = input.value === "";
            window.clearTimeout(temporizador);
            temporizador = window.setTimeout(buscar, 180);
        });

        input.addEventListener("focus", buscar);
        input.addEventListener("click", function () { if (!aberta()) buscar(); });

        input.addEventListener("blur", function () {
            fechar();
            if (input.value.trim() === "") {
                if (confirmado !== "") zerar(false);   // apagou o texto: remove a escolha
            } else {
                input.value = confirmado;               // texto sem escolha na lista: volta ao que estava valendo
            }
            limpar.hidden = input.value === "";
        });

        input.addEventListener("keydown", function (e) {
            var total = opcoes.length;
            if (e.key === "ArrowDown") {
                e.preventDefault();
                if (!aberta()) { buscar(); return; }
                if (total) destacar((ativo + 1) % total);
            } else if (e.key === "ArrowUp") {
                e.preventDefault();
                if (aberta() && total) destacar(ativo <= 0 ? total - 1 : ativo - 1);
            } else if (e.key === "Enter") {
                if (aberta() && total) {
                    e.preventDefault();
                    selecionar(opcoes[ativo >= 0 ? ativo : 0]);
                }
            } else if (e.key === "Escape") {
                if (aberta()) { e.stopPropagation(); fechar(); }
            }
        });

        // mousedown sem tirar o foco do campo (senão o "blur" esconderia o botão antes do clique)
        limpar.addEventListener("mousedown", function (e) { e.preventDefault(); });
        limpar.addEventListener("click", function () {
            zerar(false);
            input.focus();
        });

        // A página pode definir o valor sem avisar mudança (ex.: a janela de filtros do painel ao restaurar ou limpar)
        el.addEventListener("combo:definir", function (e) {
            var valor = e.detail && e.detail.valor != null ? String(e.detail.valor) : "";
            if (valor === "") { zerar(true); return; }
            oculto.value = valor;
            confirmado = valor;
            input.value = valor;
            limpar.hidden = false;
            fechar();
        });

        // ----- Bairro depende da Cidade: trocou ou limpou a cidade, o bairro escolhido deixa de valer -----
        if (dependeDe) {
            // fase de captura: roda antes de quem escuta o evento (ex.: a listagem, que envia o formulário)
            document.addEventListener("combo:change", function (e) {
                if (combos[dependeDe] && e.target === combos[dependeDe].el) zerar(true);
            }, true);
        }

        // Ao voltar pelo navegador, o campo visível precisa continuar igual ao valor guardado
        window.addEventListener("pageshow", function () {
            confirmado = oculto.value;
            input.value = confirmado;
            limpar.hidden = confirmado === "";
        });
    }

    // ==========================================================================
    // Seletor simples (lista fixa) — mesmo visual do combo
    // ==========================================================================
    function iniciarSeletor(el) {
        var gatilho = el.querySelector(".combo__gatilho");
        var textoEl = el.querySelector(".combo__valor");
        var oculto = el.querySelector("input[type=hidden]");
        var lista = el.querySelector(".combo__lista");
        var opcoes = Array.prototype.slice.call(lista.querySelectorAll(".combo__opcao"));
        var ativo = -1;

        function aberta() { return !lista.hidden; }

        function destacar(indice) {
            opcoes.forEach(function (li, n) { li.classList.toggle("is-active", n === indice); });
            ativo = indice;
            if (indice >= 0) opcoes[indice].scrollIntoView({ block: "nearest" });
        }

        function abrir() {
            lista.hidden = false;
            gatilho.setAttribute("aria-expanded", "true");
            el.classList.add("is-open");
            var atual = opcoes.findIndex(function (li) { return li.getAttribute("data-valor") === oculto.value; });
            destacar(atual);
        }

        function fechar() {
            lista.hidden = true;
            gatilho.setAttribute("aria-expanded", "false");
            el.classList.remove("is-open");
            ativo = -1;
        }

        function escolher(indice) {
            var li = opcoes[indice];
            if (!li) return;
            oculto.value = li.getAttribute("data-valor") || "";
            textoEl.textContent = li.textContent;
            textoEl.classList.toggle("is-placeholder", oculto.value === "");
            opcoes.forEach(function (o, n) {
                o.classList.toggle("is-selected", n === indice);
                o.setAttribute("aria-selected", n === indice ? "true" : "false");
            });
            fechar();
            el.dispatchEvent(new CustomEvent("combo:change", { bubbles: true }));
        }

        function ligarOpcoes() {
            opcoes.forEach(function (li, n) {
                li.addEventListener("mousedown", function (e) { e.preventDefault(); escolher(n); });
            });
        }
        ligarOpcoes();

        // A página pode trocar a lista de opções (ex.: os imóveis do lead, que só são conhecidos depois de carregar):
        //   seletor.dispatchEvent(new CustomEvent("combo:opcoes", { detail: { opcoes: [{ valor: "1", rotulo: "A1B2C" }], valor: "1" } }));
        // Não dispara "combo:change". Sem "valor", fica a primeira opção.
        el.addEventListener("combo:opcoes", function (e) {
            var novas = e.detail && Array.isArray(e.detail.opcoes) ? e.detail.opcoes : [];
            if (novas.length === 0) return;

            lista.innerHTML = "";
            novas.forEach(function (o) {
                var li = document.createElement("li");
                li.className = "combo__opcao";
                li.setAttribute("role", "option");
                li.setAttribute("data-valor", String(o.valor));
                li.textContent = o.rotulo;
                lista.appendChild(li);
            });

            opcoes = Array.prototype.slice.call(lista.querySelectorAll(".combo__opcao"));
            ligarOpcoes();

            var alvo = e.detail.valor != null ? String(e.detail.valor) : "";
            var i = opcoes.findIndex(function (li) { return li.getAttribute("data-valor") === alvo; });
            if (i < 0) i = 0;

            oculto.value = opcoes[i].getAttribute("data-valor") || "";
            textoEl.textContent = opcoes[i].textContent;
            textoEl.classList.toggle("is-placeholder", oculto.value === "");
            opcoes.forEach(function (o, n) {
                o.classList.toggle("is-selected", n === i);
                o.setAttribute("aria-selected", n === i ? "true" : "false");
            });
            ativo = -1;
        });

        // A página pode escolher uma opção pelo código (ex.: botões do banner de Anunciar imóvel)
        el.addEventListener("combo:definir", function (e) {
            var valor = e.detail && e.detail.valor != null ? String(e.detail.valor) : "";
            var indice = opcoes.findIndex(function (li) { return li.getAttribute("data-valor") === valor; });
            if (indice >= 0) escolher(indice);
        });

        gatilho.addEventListener("click", function () { aberta() ? fechar() : abrir(); });
        gatilho.addEventListener("blur", fechar);

        gatilho.addEventListener("keydown", function (e) {
            if (e.key === "ArrowDown") {
                e.preventDefault();
                if (!aberta()) abrir(); else destacar((ativo + 1) % opcoes.length);
            } else if (e.key === "ArrowUp") {
                e.preventDefault();
                if (!aberta()) abrir(); else destacar(ativo <= 0 ? opcoes.length - 1 : ativo - 1);
            } else if ((e.key === "Enter" || e.key === " ") && aberta()) {
                e.preventDefault();
                if (ativo >= 0) escolher(ativo); else fechar();
            } else if (e.key === "Escape" && aberta()) {
                e.stopPropagation();
                fechar();
            }
        });

        // Estado inicial: a opção já marcada pelo servidor (se houver)
        var inicial = opcoes.findIndex(function (li) { return li.getAttribute("data-valor") === oculto.value; });
        if (inicial < 0) inicial = 0;
        textoEl.textContent = opcoes[inicial].textContent;
        textoEl.classList.toggle("is-placeholder", (opcoes[inicial].getAttribute("data-valor") || "") === "");
        opcoes[inicial].classList.add("is-selected");

        // Ao voltar pelo navegador, reaplica o valor guardado
        window.addEventListener("pageshow", function () {
            var i = opcoes.findIndex(function (li) { return li.getAttribute("data-valor") === oculto.value; });
            if (i < 0) i = 0;
            textoEl.textContent = opcoes[i].textContent;
            textoEl.classList.toggle("is-placeholder", (opcoes[i].getAttribute("data-valor") || "") === "");
            opcoes.forEach(function (o, n) { o.classList.toggle("is-selected", n === i); });
        });
    }

    // A Cidade precisa existir antes do Bairro (que depende dela)
    var elCombos = Array.prototype.slice.call(document.querySelectorAll("[data-combo]"));
    elCombos.sort(function (a, b) {
        return (a.hasAttribute("data-depende") ? 1 : 0) - (b.hasAttribute("data-depende") ? 1 : 0);
    });
    elCombos.forEach(iniciarCombo);

    document.querySelectorAll("[data-seletor]").forEach(iniciarSeletor);
})();
