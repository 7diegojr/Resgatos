namespace BetelImoveis.Constants;

/// <summary>
/// Nomes das ações gravadas no histórico que outras telas precisam reconhecer
/// (ex.: a Lixeira procura quem excluiu o imóvel). Usar sempre estas constantes ao registrar essas ações.
/// </summary>
public static class HistoricoAcoes
{
    public const string Excluido = "Imóvel excluído";
    public const string Restaurado = "Imóvel restaurado";
    public const string ExcluidoDefinitivamente = "Imóvel excluído permanentemente";

    public const string CorretorCadastrado = "Corretor cadastrado";
    public const string CorretorEditado = "Corretor editado";
    public const string CorretorAtivado = "Corretor ativado";
    public const string CorretorInativado = "Corretor inativado";

    public const string UsuarioCadastrado = "Usuário cadastrado";
    public const string UsuarioEditado = "Usuário editado";
    public const string UsuarioAtivado = "Usuário ativado";
    public const string UsuarioInativado = "Usuário inativado";
    public const string TipoAcessoAlterado = "Tipo de acesso alterado";
    public const string SenhaRedefinida = "Senha redefinida";

    // ----- Leads, clientes e visitas -----
    // Cada nome cai em uma das 3 cores do Histórico (ver HistoricoAcaoTipo.TipoDaAcao):
    //   verde (criar/adicionar/agendar): contém "cadastr", "criad", "adicionad", "agendad" ou "restaurad"
    //   vermelho (remover): contém "exclu" ou "apagad"; amarelo: todo o resto.
    // A descrição traz só o código do lead (sem nome ou telefone), para a exclusão de dados não deixar rastro.
    public const string LeadCriado = "Lead criado";
    public const string LeadEtapaAlterada = "Etapa do lead alterada";
    public const string LeadFechado = "Negócio fechado";
    public const string LeadPerdido = "Lead marcado como perdido";
    public const string LeadReatribuido = "Lead reatribuído";
    public const string LeadImovelAlterado = "Imóveis do lead alterados";
    public const string LeadExcluido = "Lead excluído permanentemente";
    public const string InteracaoAdicionada = "Interação adicionada";
    public const string ClienteCadastrado = "Cliente cadastrado manualmente";
    public const string ClienteCriadoDoLead = "Cliente criado a partir de lead";
    public const string VisitaAgendada = "Visita agendada";
    public const string VisitaAtualizada = "Visita atualizada";
}
