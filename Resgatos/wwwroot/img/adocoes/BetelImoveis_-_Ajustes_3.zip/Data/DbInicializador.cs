using BetelImoveis.Constants;
using BetelImoveis.Helpers;
using BetelImoveis.Models.Entities;
using BetelImoveis.Models.Enums;
using BetelImoveis.Services;
using Microsoft.EntityFrameworkCore;

namespace BetelImoveis.Data;

/// <summary>
/// Criação inicial do banco (EnsureCreatedAsync, sem Migrations) e seed manual:
/// diferenciais padrão + perfis de teste da BASE INICIAL.
/// </summary>
public static class DbInicializador
{
    // Contas de teste da equipe (nomes iguais aos da página "Sobre nós"; fotos em wwwroot/img/sobre/).
    // ATENÇÃO: senhas de teste. Trocar/remover antes de qualquer publicação.
    private sealed record PessoaSeed(
        string Nome, string Email, string Senha, TipoUsuario[] Perfis,
        string? FotoCorretor = null, string? FotoUsuario = null,
        string? Telefone = null, string? Whatsapp = null, string? Creci = null);

    private const string EmailMarcos = "marcos@betelimoveis.com.br";
    private const string EmailJuliana = "juliana@betelimoveis.com.br";

    // Marcos é Administrador E Corretor. Juliana (marketing e recepção) é só Administradora: não tem cadastro de
    // corretor, então a foto dela fica no próprio usuário. Telefones e CRECI são fictícios.
    private static readonly PessoaSeed[] Equipe =
    {
        new("Marcos Oliveira", EmailMarcos, "marcos123",
            new[] { TipoUsuario.Administrador, TipoUsuario.Corretor },
            FotoCorretor: "/img/sobre/proprietario-corretor.png",
            Telefone: "(14) 3234-5501", Whatsapp: "(14) 99701-5501", Creci: "28410-F"),
        new("Lucas Ferreira", "lucas@betelimoveis.com.br", "lucas123",
            new[] { TipoUsuario.Corretor },
            FotoCorretor: "/img/sobre/corretor.png",
            Telefone: "(14) 3234-5502", Whatsapp: "(14) 99701-5502", Creci: "31275-F"),
        new("Camila Duarte", "camila@betelimoveis.com.br", "camila123",
            new[] { TipoUsuario.Corretor },
            FotoCorretor: "/img/sobre/corretora.png",
            Telefone: "(14) 3234-5503", Whatsapp: "(14) 99701-5503", Creci: "35902-F"),
        new("Juliana Ramos", EmailJuliana, "juliana123",
            new[] { TipoUsuario.Administrador },
            FotoUsuario: "/img/sobre/marketing-recepcao.png")
    };

    // Todas as datas de teste (cadastro, Lixeira, fechamento e histórico) ficam neste período: 12/10/2026 a 21/10/2026.
    private static readonly DateTime PeriodoInicio = new(2026, 10, 12, 0, 0, 0);
    private static readonly DateTime PeriodoFim = new(2026, 10, 21, 23, 59, 0);

    /// <summary>Último instante possível: o fim do período, ou agora se o relógio ainda não chegou lá (nada no futuro).</summary>
    private static DateTime FimEfetivo(DateTime agora) => agora < PeriodoFim ? agora : PeriodoFim;

    /// <summary>
    /// Data diversa dentro do período para o item "indice" de "total": espalha pelos dias de 12/10 a 21/10, com horários
    /// comerciais variados. "ate" limita o último dia usado (para sobrar tempo para eventos posteriores).
    /// </summary>
    private static DateTime DataNoPeriodo(int indice, int total, DateTime ate)
    {
        var dias = Math.Max(0, (int)(ate.Date - PeriodoInicio.Date).TotalDays);
        var dia = total <= 1 ? 0 : Math.Min(dias, (int)Math.Floor(indice * (dias + 1.0) / total));
        var data = PeriodoInicio.Date.AddDays(dia).AddHours(8 + indice * 7 % 11).AddMinutes(indice * 13 % 60);
        return data > ate ? ate.AddMinutes(-(5 + indice * 11 % 240)) : data;
    }

    /// <summary>Um ponto entre "inicio" e o fim do período (fracao 0 a 1), usado para eventos que acontecem depois do cadastro.</summary>
    private static DateTime Entre(DateTime inicio, DateTime fim, double fracao)
    {
        var d = inicio.AddTicks((long)((fim - inicio).Ticks * Math.Clamp(fracao, 0, 1)));

        // Horário comercial (8h às 18h), para as datas parecerem de um dia normal de trabalho
        if (d.Hour < 8) d = d.Date.AddHours(8).AddMinutes(d.Minute);
        else if (d.Hour >= 19) d = d.Date.AddHours(18).AddMinutes(d.Minute);

        return d < inicio ? inicio : d > fim ? fim : d;
    }

    // Contas de teste antigas: saem do banco, e os imóveis delas passam para os corretores da equipe.
    private static readonly string[] UsuariosRemovidos = { "admin@gmail.com", "diegojr@gmail.com" };

    public static async Task InicializarAsync(IServiceProvider services, CancellationToken ct = default)
    {
        using var scope = services.CreateScope();
        var sp = scope.ServiceProvider;

        var db = sp.GetRequiredService<AppDbContext>();
        var hasher = sp.GetRequiredService<ISenhaHasher>();
        var logger = sp.GetRequiredService<ILoggerFactory>().CreateLogger(nameof(DbInicializador));

        await db.Database.EnsureCreatedAsync(ct);
        await AtualizarEstruturaAsync(db, logger, ct);
        await AtualizarCodigosImovelAsync(db, logger, ct);
        await AtualizarLeadsAsync(db, logger, ct);

        await SeedDiferenciaisAsync(db, ct);
        await SeedUsuariosAsync(db, hasher, logger, ct);

        // Imóveis de teste (25, com fotos): somente em Development e somente se a tabela estiver vazia.
        var env = sp.GetRequiredService<IHostEnvironment>();
        if (env.IsDevelopment())
        {
            await SeedImoveisTesteAsync(db, logger, ct);
            await DbSeedLeads.SeedAsync(db, logger, ct);
        }
    }

    // ---------- Leads, funil de vendas, clientes, interações e visitas ----------

    /// <summary>
    /// Cria (se ainda não existirem) as tabelas de clientes, leads, lead_imoveis, interacoes e visitas e a coluna
    /// imoveis.data_fechamento. Em bancos novos o EnsureCreated já cria tudo e esta rotina não muda nada.
    /// Em bancos antigos (sem Migrations) ela traz a estrutura nova sem apagar dados. Os mesmos comandos estão em Scripts/leads-tabelas.sql.
    /// </summary>
    private static async Task AtualizarLeadsAsync(AppDbContext db, ILogger logger, CancellationToken ct)
    {
        var comandos = new[]
        {
        "CREATE TABLE IF NOT EXISTS clientes ( "
        + "id INT NOT NULL AUTO_INCREMENT, "
        + "nome VARCHAR(150) NOT NULL, "
        + "telefone VARCHAR(30) NOT NULL, "
        + "telefone_normalizado VARCHAR(20) NOT NULL, "
        + "observacoes TEXT NULL, "
        + "corretor_responsavel_id INT NULL, "
        + "ativo TINYINT(1) NOT NULL DEFAULT 1, "
        + "manual TINYINT(1) NOT NULL DEFAULT 0, "
        + "created_at DATETIME(6) NULL, "
        + "updated_at DATETIME(6) NULL, "
        + "PRIMARY KEY (id), "
        + "INDEX IX_clientes_telefone_normalizado (telefone_normalizado), "
        + "CONSTRAINT fk_clientes_corretor FOREIGN KEY (corretor_responsavel_id) REFERENCES corretores (id) ON DELETE SET NULL "
        + ") CHARACTER SET utf8mb4 ",
        "CREATE TABLE IF NOT EXISTS leads ( "
        + "id INT NOT NULL AUTO_INCREMENT, "
        + "nome VARCHAR(150) NOT NULL, "
        + "telefone VARCHAR(30) NOT NULL, "
        + "telefone_normalizado VARCHAR(20) NOT NULL, "
        + "mensagem TEXT NULL, "
        + "origem VARCHAR(20) NOT NULL, "
        + "assunto VARCHAR(200) NULL, "
        + "imovel_id INT NULL, "
        + "corretor_id INT NULL, "
        + "cliente_id INT NULL, "
        + "status VARCHAR(20) NOT NULL, "
        + "motivo_perda VARCHAR(30) NULL, "
        + "observacao_perda VARCHAR(200) NULL, "
        + "tipo_negocio VARCHAR(20) NULL, "
        + "valor_negocio DECIMAL(15,2) NULL, "
        + "primeiro_atendimento_em DATETIME(6) NULL, "
        + "etapa_alterada_em DATETIME(6) NULL, "
        + "encerrado_em DATETIME(6) NULL, "
        + "created_at DATETIME(6) NULL, "
        + "updated_at DATETIME(6) NULL, "
        + "PRIMARY KEY (id), "
        + "INDEX IX_leads_status (status), "
        + "INDEX IX_leads_corretor_id (corretor_id), "
        + "INDEX IX_leads_created_at (created_at), "
        + "INDEX IX_leads_telefone_normalizado (telefone_normalizado), "
        + "CONSTRAINT fk_leads_imovel FOREIGN KEY (imovel_id) REFERENCES imoveis (id) ON DELETE SET NULL, "
        + "CONSTRAINT fk_leads_corretor FOREIGN KEY (corretor_id) REFERENCES corretores (id) ON DELETE SET NULL, "
        + "CONSTRAINT fk_leads_cliente FOREIGN KEY (cliente_id) REFERENCES clientes (id) ON DELETE SET NULL "
        + ") CHARACTER SET utf8mb4 ",
        "CREATE TABLE IF NOT EXISTS lead_imoveis ( "
        + "lead_id INT NOT NULL, "
        + "imovel_id INT NOT NULL, "
        + "created_at DATETIME(6) NULL, "
        + "PRIMARY KEY (lead_id, imovel_id), "
        + "CONSTRAINT fk_lead_imoveis_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE, "
        + "CONSTRAINT fk_lead_imoveis_imovel FOREIGN KEY (imovel_id) REFERENCES imoveis (id) ON DELETE CASCADE "
        + ") CHARACTER SET utf8mb4 ",
        "CREATE TABLE IF NOT EXISTS cliente_imoveis ( "
        + "cliente_id INT NOT NULL, "
        + "imovel_id INT NOT NULL, "
        + "created_at DATETIME(6) NULL, "
        + "PRIMARY KEY (cliente_id, imovel_id), "
        + "CONSTRAINT fk_cliente_imoveis_cliente FOREIGN KEY (cliente_id) REFERENCES clientes (id) ON DELETE CASCADE, "
        + "CONSTRAINT fk_cliente_imoveis_imovel FOREIGN KEY (imovel_id) REFERENCES imoveis (id) ON DELETE CASCADE "
        + ") CHARACTER SET utf8mb4 ",
        "CREATE TABLE IF NOT EXISTS interacoes ( "
        + "id INT NOT NULL AUTO_INCREMENT, "
        + "lead_id INT NULL, "
        + "cliente_id INT NULL, "
        + "usuario_id INT NULL, "
        + "tipo VARCHAR(20) NOT NULL, "
        + "descricao TEXT NOT NULL, "
        + "data_hora DATETIME(6) NOT NULL, "
        + "PRIMARY KEY (id), "
        + "INDEX IX_interacoes_lead_id (lead_id), "
        + "INDEX IX_interacoes_cliente_id (cliente_id), "
        + "CONSTRAINT fk_interacoes_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE, "
        + "CONSTRAINT fk_interacoes_cliente FOREIGN KEY (cliente_id) REFERENCES clientes (id) ON DELETE CASCADE, "
        + "CONSTRAINT fk_interacoes_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE SET NULL "
        + ") CHARACTER SET utf8mb4 ",
        "CREATE TABLE IF NOT EXISTS visitas ( "
        + "id INT NOT NULL AUTO_INCREMENT, "
        + "lead_id INT NOT NULL, "
        + "imovel_id INT NULL, "
        + "corretor_id INT NULL, "
        + "data_hora DATETIME(6) NOT NULL, "
        + "status VARCHAR(20) NOT NULL, "
        + "observacoes TEXT NULL, "
        + "interesse VARCHAR(20) NULL, "
        + "feedback_observacao TEXT NULL, "
        + "feedback_em DATETIME(6) NULL, "
        + "created_at DATETIME(6) NULL, "
        + "PRIMARY KEY (id), "
        + "INDEX IX_visitas_data_hora (data_hora), "
        + "CONSTRAINT fk_visitas_lead FOREIGN KEY (lead_id) REFERENCES leads (id) ON DELETE CASCADE, "
        + "CONSTRAINT fk_visitas_imovel FOREIGN KEY (imovel_id) REFERENCES imoveis (id) ON DELETE SET NULL, "
        + "CONSTRAINT fk_visitas_corretor FOREIGN KEY (corretor_id) REFERENCES corretores (id) ON DELETE SET NULL "
        + ") CHARACTER SET utf8mb4 ",
        };

        try
        {
            foreach (var comando in comandos)
                await db.Database.ExecuteSqlRawAsync(comando, ct);

            // Clientes criados antes do cadastro manual: a coluna "manual" começa em 0 (não manual)
            var colunaManual = await db.Database.SqlQueryRaw<int>(
                "SELECT COUNT(*) AS `Value` FROM information_schema.columns " +
                "WHERE table_schema = DATABASE() AND table_name = 'clientes' AND column_name = 'manual'").SingleAsync(ct);

            if (colunaManual == 0)
            {
                await db.Database.ExecuteSqlRawAsync("ALTER TABLE clientes ADD COLUMN manual TINYINT(1) NOT NULL DEFAULT 0", ct);
                logger.LogWarning("Banco atualizado: criada a coluna clientes.manual.");
            }

            var coluna = await db.Database.SqlQueryRaw<int>(
                "SELECT COUNT(*) AS `Value` FROM information_schema.columns " +
                "WHERE table_schema = DATABASE() AND table_name = 'imoveis' AND column_name = 'data_fechamento'").SingleAsync(ct);

            if (coluna == 0)
            {
                await db.Database.ExecuteSqlRawAsync("ALTER TABLE imoveis ADD COLUMN data_fechamento DATETIME(6) NULL", ct);

                // Quem já estava Vendido ou Alugado usa a data da última alteração como data de fechamento
                await db.Database.ExecuteSqlRawAsync(
                    "UPDATE imoveis SET data_fechamento = updated_at WHERE status IN ('VENDIDO', 'ALUGADO') AND data_fechamento IS NULL", ct);

                logger.LogWarning("Banco atualizado: criada a coluna imoveis.data_fechamento.");
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Não foi possível criar as tabelas de leads. Aplique o script Scripts/leads-tabelas.sql ou recrie o banco de desenvolvimento.");
            throw;
        }
    }

    private static async Task SeedDiferenciaisAsync(AppDbContext db, CancellationToken ct)
    {
        if (await db.Diferenciais.AnyAsync(ct)) return;

        var padrao = new (CategoriaDiferencial Categoria, string Nome)[]
        {
            (CategoriaDiferencial.Imovel, "Suíte"),
            (CategoriaDiferencial.Imovel, "Varanda"),
            (CategoriaDiferencial.Imovel, "Churrasqueira"),
            (CategoriaDiferencial.Imovel, "Móveis planejados"),

            (CategoriaDiferencial.Condominio, "Piscina"),
            (CategoriaDiferencial.Condominio, "Academia"),
            (CategoriaDiferencial.Condominio, "Salão de festas"),
            (CategoriaDiferencial.Condominio, "Elevador"),

            (CategoriaDiferencial.Seguranca, "Portaria"),
            (CategoriaDiferencial.Seguranca, "Câmeras"),
            (CategoriaDiferencial.Seguranca, "Controle de acesso"),

            (CategoriaDiferencial.Acessibilidade, "Elevador"),
            (CategoriaDiferencial.Acessibilidade, "Rampas"),
            (CategoriaDiferencial.Acessibilidade, "Adaptações")
        };

        db.Diferenciais.AddRange(padrao.Select(d => new Diferencial
        {
            Categoria = d.Categoria,
            Nome = d.Nome,
            Ativo = true
        }));

        await db.SaveChangesAsync(ct);
    }

    /// <summary>
    /// Bancos criados antes dos perfis múltiplos tinham a coluna usuarios.tipo (um único perfil por usuário).
    /// Como não há Migrations, esta rotina cria a tabela usuario_perfis, copia o tipo antigo de cada usuário para ela
    /// e remove a coluna antiga. Em um banco novo (já criado com a estrutura atual) ela não faz nada.
    /// </summary>
    private static async Task AtualizarEstruturaAsync(AppDbContext db, ILogger logger, CancellationToken ct)
    {
        try
        {
            await db.Database.ExecuteSqlRawAsync(
                "CREATE TABLE IF NOT EXISTS usuario_perfis (" +
                "usuario_id INT NOT NULL, " +
                "perfil VARCHAR(20) NOT NULL, " +
                "PRIMARY KEY (usuario_id, perfil), " +
                "CONSTRAINT fk_usuario_perfis_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios (id) ON DELETE CASCADE)", ct);

            var colunaAntiga = await db.Database.SqlQueryRaw<int>(
                "SELECT COUNT(*) AS `Value` FROM information_schema.columns " +
                "WHERE table_schema = DATABASE() AND table_name = 'usuarios' AND column_name = 'tipo'").SingleAsync(ct);

            if (colunaAntiga > 0)
            {
                await db.Database.ExecuteSqlRawAsync("INSERT IGNORE INTO usuario_perfis (usuario_id, perfil) SELECT id, tipo FROM usuarios", ct);
                await db.Database.ExecuteSqlRawAsync("ALTER TABLE usuarios DROP COLUMN tipo", ct);
                logger.LogWarning("Banco atualizado: o tipo de cada usuário foi copiado para a tabela usuario_perfis.");
            }

            // Foto do usuário (para quem não tem cadastro de corretor, como a administradora de marketing)
            var colunaFoto = await db.Database.SqlQueryRaw<int>(
                "SELECT COUNT(*) AS `Value` FROM information_schema.columns " +
                "WHERE table_schema = DATABASE() AND table_name = 'usuarios' AND column_name = 'foto_url'").SingleAsync(ct);

            if (colunaFoto == 0)
                await db.Database.ExecuteSqlRawAsync("ALTER TABLE usuarios ADD COLUMN foto_url VARCHAR(500) NULL", ct);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Não foi possível atualizar a estrutura de usuários e perfis. Se o erro continuar, recrie o banco de desenvolvimento.");
            throw;
        }
    }

    /// <summary>
    /// Código público do imóvel (5 caracteres, ex.: K7M2P) no lugar do número sequencial.
    /// Em bancos criados antes dessa mudança (sem Migrations): cria a tabela codigos_imovel (todo código já emitido,
    /// nunca apagado), cria a coluna imoveis.codigo, dá um código novo a cada imóvel existente (inclusive os da Lixeira),
    /// torna a coluna obrigatória e cria o índice único. Em um banco novo (já criado com a estrutura atual) não faz nada.
    /// </summary>
    private static async Task AtualizarCodigosImovelAsync(AppDbContext db, ILogger logger, CancellationToken ct)
    {
        try
        {
            await db.Database.ExecuteSqlRawAsync(
                "CREATE TABLE IF NOT EXISTS codigos_imovel (" +
                "codigo VARCHAR(5) NOT NULL, " +
                "criado_em DATETIME(6) NOT NULL, " +
                "PRIMARY KEY (codigo))", ct);

            var coluna = await db.Database.SqlQueryRaw<int>(
                "SELECT COUNT(*) AS `Value` FROM information_schema.columns " +
                "WHERE table_schema = DATABASE() AND table_name = 'imoveis' AND column_name = 'codigo'").SingleAsync(ct);

            if (coluna == 0)
                await db.Database.ExecuteSqlRawAsync("ALTER TABLE imoveis ADD COLUMN codigo VARCHAR(5) NULL", ct);

            // Imóveis sem código (todos, na primeira vez): cada um recebe um código novo, reservado na tabela codigos_imovel
            var semCodigo = await db.Database.SqlQueryRaw<int>(
                "SELECT id AS `Value` FROM imoveis WHERE codigo IS NULL OR codigo = '' ORDER BY id").ToListAsync(ct);

            foreach (var id in semCodigo)
            {
                var codigo = await CodigoImovelHelper.ReservarAsync(db, ct);
                await db.Database.ExecuteSqlInterpolatedAsync($"UPDATE imoveis SET codigo = {codigo} WHERE id = {id}", ct);
            }

            if (semCodigo.Count > 0)
                logger.LogWarning("Banco atualizado: {Total} imóveis receberam o novo código de 5 caracteres.", semCodigo.Count);

            // Garante que todo código em uso está no registro de códigos emitidos (que nunca perde linhas)
            await db.Database.ExecuteSqlRawAsync(
                "INSERT IGNORE INTO codigos_imovel (codigo, criado_em) SELECT codigo, UTC_TIMESTAMP(6) FROM imoveis WHERE codigo IS NOT NULL AND codigo <> ''", ct);

            var aceitaNulo = await db.Database.SqlQueryRaw<string>(
                "SELECT IS_NULLABLE AS `Value` FROM information_schema.columns " +
                "WHERE table_schema = DATABASE() AND table_name = 'imoveis' AND column_name = 'codigo'").SingleAsync(ct);

            if (string.Equals(aceitaNulo, "YES", StringComparison.OrdinalIgnoreCase))
                await db.Database.ExecuteSqlRawAsync("ALTER TABLE imoveis MODIFY COLUMN codigo VARCHAR(5) NOT NULL", ct);

            var indiceUnico = await db.Database.SqlQueryRaw<int>(
                "SELECT COUNT(*) AS `Value` FROM information_schema.statistics " +
                "WHERE table_schema = DATABASE() AND table_name = 'imoveis' AND column_name = 'codigo' AND non_unique = 0").SingleAsync(ct);

            if (indiceUnico == 0)
                await db.Database.ExecuteSqlRawAsync("CREATE UNIQUE INDEX IX_imoveis_Codigo ON imoveis (codigo)", ct);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Não foi possível atualizar os códigos dos imóveis. Se o erro continuar, recrie o banco de desenvolvimento.");
            throw;
        }
    }

    private static async Task SeedUsuariosAsync(AppDbContext db, ISenhaHasher hasher, ILogger logger, CancellationToken ct)
    {
        foreach (var pessoa in Equipe)
            await GarantirUsuarioAsync(db, hasher, pessoa, ct);

        foreach (var email in UsuariosRemovidos)
            await RemoverUsuarioDeTesteAsync(db, email, logger, ct);

        logger.LogWarning("Contas de teste da equipe garantidas no banco (Marcos: admin + corretor; Juliana: admin). Altere as senhas antes de publicar.");
    }

    /// <summary>
    /// Cria o usuário se ele não existir e garante os perfis pedidos. Quem tem o perfil Corretor ganha também o cadastro
    /// de corretor, com TODAS as informações (telefone, WhatsApp, e-mail, CRECI e foto). Campos já preenchidos não são
    /// alterados. Pode rodar várias vezes sem duplicar nada.
    /// </summary>
    private static async Task GarantirUsuarioAsync(AppDbContext db, ISenhaHasher hasher, PessoaSeed pessoa, CancellationToken ct)
    {
        var existente = await db.Usuarios
            .Include(u => u.Perfis)
            .Include(u => u.Corretor)
            .FirstOrDefaultAsync(u => u.Email == pessoa.Email, ct);

        var usuario = existente ?? new Usuario
        {
            Nome = pessoa.Nome,
            Email = pessoa.Email,
            SenhaHash = hasher.Hash(pessoa.Senha),
            Ativo = true
        };

        if (existente is null)
            db.Usuarios.Add(usuario);

        if (string.IsNullOrWhiteSpace(usuario.FotoUrl) && pessoa.FotoUsuario is not null)
            usuario.FotoUrl = pessoa.FotoUsuario;

        foreach (var perfil in pessoa.Perfis.Where(p => !usuario.Perfis.Any(x => x.Perfil == p)))
            usuario.Perfis.Add(new UsuarioPerfil { Perfil = perfil });

        if (pessoa.Perfis.Contains(TipoUsuario.Corretor))
        {
            var corretor = usuario.Corretor ??= new Corretor { Nome = pessoa.Nome, Email = pessoa.Email, Ativo = true };

            if (string.IsNullOrWhiteSpace(corretor.Email)) corretor.Email = pessoa.Email;
            if (string.IsNullOrWhiteSpace(corretor.Telefone)) corretor.Telefone = pessoa.Telefone;
            if (string.IsNullOrWhiteSpace(corretor.Whatsapp)) corretor.Whatsapp = pessoa.Whatsapp;
            if (string.IsNullOrWhiteSpace(corretor.Creci)) corretor.Creci = pessoa.Creci;
            if (string.IsNullOrWhiteSpace(corretor.FotoUrl)) corretor.FotoUrl = pessoa.FotoCorretor;
        }

        await db.SaveChangesAsync(ct);
    }

    /// <summary>
    /// Remove uma conta de teste antiga. Os imóveis dela (inclusive os da Lixeira) passam para os corretores da equipe,
    /// sempre para quem tem menos imóveis. O histórico escrito por essa conta (dados de teste) sai junto.
    /// </summary>
    private static async Task RemoverUsuarioDeTesteAsync(AppDbContext db, string email, ILogger logger, CancellationToken ct)
    {
        var usuario = await db.Usuarios.Include(u => u.Corretor).FirstOrDefaultAsync(u => u.Email == email, ct);
        if (usuario is null) return;

        if (usuario.Corretor is { } corretor)
        {
            var emailsEquipe = Equipe.Where(p => p.Perfis.Contains(TipoUsuario.Corretor)).Select(p => p.Email).ToList();
            var destinos = await db.Corretores
                .Where(c => c.Id != corretor.Id && c.Email != null && emailsEquipe.Contains(c.Email))
                .OrderBy(c => c.Id)
                .ToListAsync(ct);

            if (destinos.Count > 0)
            {
                var vivos = new Dictionary<int, int>();
                var lixeira = new Dictionary<int, int>();
                foreach (var d in destinos)
                {
                    vivos[d.Id] = await db.Imoveis.CountAsync(i => i.CorretorId == d.Id && i.DeletedAt == null, ct);
                    lixeira[d.Id] = await db.Imoveis.CountAsync(i => i.CorretorId == d.Id && i.DeletedAt != null, ct);
                }

                var imoveis = await db.Imoveis.Where(i => i.CorretorId == corretor.Id).OrderBy(i => i.Id).ToListAsync(ct);
                foreach (var imovel in imoveis)
                {
                    var carga = imovel.DeletedAt == null ? vivos : lixeira;
                    var destino = destinos.OrderBy(d => carga[d.Id]).ThenBy(d => d.Id).First();
                    imovel.CorretorId = destino.Id;
                    carga[destino.Id]++;
                }

                await db.SaveChangesAsync(ct);
                logger.LogWarning("{Imoveis} imóveis de {Email} passaram para os corretores da equipe.", imoveis.Count, email);
            }

            db.Corretores.Remove(corretor);
        }

        db.Historicos.RemoveRange(await db.Historicos.Where(h => h.UsuarioId == usuario.Id).ToListAsync(ct));
        db.Usuarios.Remove(usuario);   // os perfis saem em cascata
        await db.SaveChangesAsync(ct);

        logger.LogWarning("Conta de teste antiga removida: {Email}.", email);
    }

    /// <summary>
    /// TEMPORÁRIO (apenas desenvolvimento): 42 imóveis de teste, com fotos reais, divididos entre os 3 corretores da equipe:
    /// 12 imóveis fora da Lixeira para cada um e 2 na Lixeira para cada um. Também cadastra um histórico de exemplo.
    /// São 5 "versões" de imóvel (pastas wwwroot/uploads/imoveis/v1 ... v5, fotos 1.png, 2.png...) usadas várias vezes,
    /// com dados diferentes (finalidade, bairro, valores, tamanho). A 1.png é sempre a foto principal.
    ///   v1: apartamento (7 fotos) · v2, v3, v4 e v5: sobrados/casas (10 fotos cada)
    /// Cada imóvel é identificado pelo título: só entram os que ainda não existem, então a seed pode rodar de novo sem duplicar
    /// e completa bancos que já tinham parte dos imóveis.
    /// Remova este método (e a chamada acima) quando não precisar mais dos dados de teste.
    /// </summary>
    private static async Task SeedImoveisTesteAsync(AppDbContext db, ILogger logger, CancellationToken ct)
    {
        // Dono dos imóveis: os corretores da equipe (Marcos, Lucas e Camila)
        var emailsCorretores = Equipe.Where(p => p.Perfis.Contains(TipoUsuario.Corretor)).Select(p => p.Email).ToList();
        var corretores = await db.Corretores
            .Where(c => c.Email != null && emailsCorretores.Contains(c.Email))
            .OrderBy(c => c.Id)
            .ToListAsync(ct);

        if (corretores.Count == 0) return;

        var diferenciais = await db.Diferenciais.ToListAsync(ct);
        int? Dif(CategoriaDiferencial categoria, string nome) =>
            diferenciais.FirstOrDefault(d => d.Categoria == categoria && d.Nome == nome)?.Id;

        // Quantidade de fotos de cada versão (wwwroot/uploads/imoveis/v{versão}/1.png até N.png)
        var fotosPorVersao = new Dictionary<int, int> { [1] = 7, [2] = 10, [3] = 10, [4] = 10, [5] = 10 };

        // Descrição de cada versão: o texto descreve o que aparece nas fotos e usa os números do próprio imóvel.
        // Cada imóvel acrescenta uma abertura e um parágrafo sobre a localização, para não ficarem todos iguais.
        static string Plural(int? n, string singular, string plural) => $"{n ?? 0} {((n ?? 0) == 1 ? singular : plural)}";
        static string QuartosSuites(Imovel i) =>
            i.Suites is > 0
                ? $"{i.Quartos} quartos, sendo {Plural(i.Suites, "suíte", "suítes")}"
                : $"{i.Quartos} quartos";

        var descricoes = new Dictionary<int, Func<Imovel, string, string, string>>
        {
            // v1 — apartamento
            [1] = (i, abertura, local) =>
                $"{abertura}\n\n" +
                $"A sala de estar e de jantar é integrada, com painel de TV em madeira, spots de luz e lustres de cristal, e se abre para a varanda, que recebe bastante luz natural. A cozinha é aberta para a sala, com balcão e armários planejados, e o piso em madeira deixa o apartamento ainda mais aconchegante. São {QuartosSuites(i)} e {Plural(i.Banheiros, "banheiro", "banheiros")}, em {(int)i.AreaM2!.Value} m² muito bem aproveitados.\n\n" +
                local,

            // v2 — sobrado em condomínio com área gourmet
            [2] = (i, abertura, local) =>
                $"{abertura}\n\n" +
                $"O sobrado tem dois pavimentos, com sala ampla de piso em madeira, escada em destaque, {QuartosSuites(i)} e {Plural(i.Banheiros, "banheiro", "banheiros")}, incluindo uma suíte com banheira. Os quartos são amplos e iluminados, com janelas de madeira, e os do andar de cima têm varandas.\n\n" +
                $"Na área externa, o jardim na frente e o quintal nos fundos acompanham uma área gourmet coberta com churrasqueira de tijolos, ótima para receber família e amigos. O pátio de pedra e a garagem comportam {Plural(i.VagasGaragem, "veículo", "veículos")}.\n\n" +
                local,

            // v3 — sobrado em condomínio com quintal e playground
            [3] = (i, abertura, local) =>
                $"{abertura}\n\n" +
                $"A sala de estar e de jantar é integrada e a escada fica no próprio ambiente. A cozinha tem cooktop, forno e bancada para refeições rápidas. São {QuartosSuites(i)}, todos com piso de madeira, e {Plural(i.Banheiros, "banheiro", "banheiros")}. A garagem é coberta e comporta {Plural(i.VagasGaragem, "veículo", "veículos")}.\n\n" +
                "O grande diferencial é a área externa: um salão com churrasqueira e forno de tijolos, perfeito para reunir a família, e um quintal gramado com playground e casinha de brinquedo, que as crianças vão adorar.\n\n" +
                local,

            // v4 — sobrado de rua com fachada em pedra
            [4] = (i, abertura, local) =>
                $"{abertura}\n\n" +
                $"A fachada em pedra e os janelões dão personalidade ao sobrado, que tem portão e um amplo pátio com garagem para {Plural(i.VagasGaragem, "veículo", "veículos")}. A sala é grande, com lareira, piso frio e muita luz natural, com espaço para os ambientes de estar e de jantar. A cozinha também é espaçosa, com lugar para a mesa de refeições.\n\n" +
                $"São {QuartosSuites(i)}, com armários embutidos, e {Plural(i.Banheiros, "banheiro", "banheiros")}. Um corredor lateral coberto, com cobertura translúcida, liga os cômodos do térreo. É uma ótima oportunidade para quem precisa de espaço e quer deixar o imóvel com a cara da família.\n\n" +
                local,

            // v5 — casa de estilo clássico com jardim
            [5] = (i, abertura, local) =>
                $"{abertura}\n\n" +
                $"A casa tem estilo clássico, com telhado colonial, pergolado de madeira na entrada e jardim com muita vegetação, que traz privacidade e frescor. O pátio de pedra com deck de madeira forma um ótimo espaço de convivência, e a garagem comporta {Plural(i.VagasGaragem, "veículo", "veículos")}.\n\n" +
                $"Por dentro, a sala é ampla, com portas em arco que se abrem para o jardim, e a escada leva ao andar dos quartos. São {QuartosSuites(i)}, com piso de tacos de madeira e estantes embutidas, e {Plural(i.Banheiros, "banheiro", "banheiros")}, incluindo um lavabo com cuba de mármore. A cozinha tem armários brancos e bancada de madeira.\n\n" +
                local
        };

        // Todos os imóveis de teste são montados aqui e só depois gravados (os que ainda não existem, pelo título)
        var catalogo = new List<(Imovel Imovel, bool NaLixeira)>();

        void Registrar(int versao, Imovel imovel, string abertura, string localizacao, bool naLixeira, StatusImovel status, (CategoriaDiferencial Cat, string Nome)[] difs)
        {
            imovel.Descricao = descricoes[versao](imovel, abertura, localizacao);
            imovel.Status = status;
            imovel.Ativo = true;

            // A 1.png é a foto principal; as demais seguem a numeração
            for (var n = 1; n <= fotosPorVersao[versao]; n++)
                imovel.Fotos.Add(new FotoImovel { Url = $"/uploads/imoveis/v{versao}/{n}.png", Ordem = n, Principal = n == 1 });

            foreach (var id in difs.Select(d => Dif(d.Cat, d.Nome)).Where(d => d.HasValue).Select(d => d!.Value).Distinct())
                imovel.Diferenciais.Add(new ImovelDiferencial { DiferencialId = id });

            catalogo.Add((imovel, naLixeira));
        }

        void Novo(int versao, Imovel imovel, string abertura, string localizacao, params (CategoriaDiferencial Cat, string Nome)[] difs) =>
            Registrar(versao, imovel, abertura, localizacao, false, StatusImovel.Disponivel, difs);

        // Imóvel que já nasce na Lixeira (excluído): na Lixeira o status é sempre Inativo
        void NaLixeira(int versao, Imovel imovel, string abertura, string localizacao, params (CategoriaDiferencial Cat, string Nome)[] difs) =>
            Registrar(versao, imovel, abertura, localizacao, true, StatusImovel.Inativo, difs);

        // Imóvel já Vendido ou Alugado (continua cadastrado, mas não aparece no site)
        void Concluido(StatusImovel status, int versao, Imovel imovel, string abertura, string localizacao, params (CategoriaDiferencial Cat, string Nome)[] difs) =>
            Registrar(versao, imovel, abertura, localizacao, false, status, difs);

        const CategoriaDiferencial IMV = CategoriaDiferencial.Imovel;
        const CategoriaDiferencial CON = CategoriaDiferencial.Condominio;
        const CategoriaDiferencial SEG = CategoriaDiferencial.Seguranca;
        const CategoriaDiferencial ACE = CategoriaDiferencial.Acessibilidade;

        // Os imóveis entram intercalando as versões (v1, v2, v3, v4, v5, v1...), para a listagem e o carrossel da Home
        // não mostrarem as mesmas fotos em sequência.

        // ===== Rodada 1 =====
        Novo(1, new Imovel
        {
            Titulo = "Apartamento com varanda e cozinha integrada no Jardim Estoril",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 520000m,
            Cidade = "Bauru", Bairro = "Jardim Estoril", Endereco = "Rua Pedro Álvares Cabral", Numero = "75", Complemento = "Apto 72", Cep = "17016-100",
            AreaM2 = 82m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Andar = 7, Iptu = 180m, ValorCondominio = 720m,
            Destaque = true
        },
        "Apartamento pronto para morar, com ambientes integrados, boa iluminação e muito conforto para a família.",
        "O condomínio tem piscina, salão de festas, elevador e portaria. O Jardim Estoril é um bairro nobre, com restaurantes, supermercados, escolas e serviços por perto.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"), (CON, "Piscina"), (CON, "Salão de festas"), (CON, "Elevador"), (SEG, "Portaria"));

        Novo(2, new Imovel
        {
            Titulo = "Sobrado em condomínio com área gourmet e churrasqueira",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 1150000m,
            Cidade = "Bauru", Bairro = "Jardim Infante Dom Henrique", Endereco = "Rua dos Ipês", Numero = "88", Cep = "17012-300",
            AreaM2 = 260m, Quartos = 4, Suites = 2, Banheiros = 4, VagasGaragem = 3, Salas = 3, Iptu = 420m, ValorCondominio = 780m,
            Destaque = true
        },
        "Sobrado amplo em condomínio fechado, com projeto bem distribuído e a tranquilidade de morar em rua interna e segura.",
        "O condomínio tem portaria, câmeras de monitoramento e controle de acesso, além de ruas internas calmas para as crianças brincarem. Fica perto de escolas, mercados e das principais avenidas da cidade.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"), (SEG, "Controle de acesso"));

        Novo(3, new Imovel
        {
            Titulo = "Sobrado em condomínio com quintal e espaço gourmet",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 620000m,
            Cidade = "Bauru", Bairro = "Jardim Bela Vista", Endereco = "Rua das Palmeiras", Numero = "245", Cep = "17015-200",
            AreaM2 = 150m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 2, Salas = 2, Iptu = 210m, ValorCondominio = 420m,
            Destaque = true
        },
        "Sobrado acolhedor em condomínio, ideal para famílias que querem espaço para as crianças e para receber os amigos.",
        "O condomínio tem portaria e câmeras e fica em região residencial, perto de escolas, padarias, farmácias e do comércio do bairro.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (CON, "Salão de festas"), (SEG, "Portaria"), (SEG, "Câmeras"));

        Novo(4, new Imovel
        {
            Titulo = "Sobrado com fachada em pedra, lareira e amplo pátio",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 760000m,
            Cidade = "Bauru", Bairro = "Vila Souto", Endereco = "Rua Sete de Setembro", Numero = "363", Cep = "17010-190",
            AreaM2 = 300m, Quartos = 4, Suites = 1, Banheiros = 3, VagasGaragem = 4, Salas = 2, Iptu = 340m
        },
        "Sobrado de rua com muito espaço, fachada marcante e ótimo potencial para quem quer personalizar o imóvel.",
        "Fica em rua arborizada e de fácil acesso, a poucos minutos do centro, com comércio, bancos, escolas e transporte público por perto.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"));

        Novo(5, new Imovel
        {
            Titulo = "Casa clássica com pergolado, jardim e deck",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 1680000m,
            Cidade = "Bauru", Bairro = "Altos da Cidade", Endereco = "Rua Rio Branco", Numero = "1210", Cep = "17011-130",
            AreaM2 = 350m, Quartos = 4, Suites = 2, Banheiros = 5, VagasGaragem = 4, Salas = 3, Iptu = 560m,
            Destaque = true
        },
        "Casa de alto padrão com personalidade, que combina a elegância do estilo clássico com ambientes amplos e muito bem iluminados.",
        "O bairro é um dos mais valorizados da cidade, com ruas tranquilas, restaurantes, colégios e hospitais a poucos minutos.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"), (SEG, "Câmeras"));

        // ===== Rodada 2 =====
        Novo(1, new Imovel
        {
            Titulo = "Apartamento de 2 quartos com varanda na Vila Universitária",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 2600m,
            Cidade = "Bauru", Bairro = "Vila Universitária", Endereco = "Av. Nações Unidas", Numero = "1020", Complemento = "Apto 52", Cep = "17012-000",
            AreaM2 = 72m, Quartos = 2, Suites = 1, Banheiros = 2, VagasGaragem = 1, Salas = 2, Andar = 5, Iptu = 110m, ValorCondominio = 580m
        },
        "Apartamento para alugar, bem cuidado e com móveis planejados, pronto para você se mudar.",
        "O prédio tem elevador e portaria, e a localização é ótima para quem estuda ou trabalha na região, perto de universidades, restaurantes e transporte público.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"), (CON, "Elevador"), (SEG, "Portaria"));

        Novo(2, new Imovel
        {
            Titulo = "Sobrado de 3 quartos em condomínio para alugar",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 5200m,
            Cidade = "Bauru", Bairro = "Jardim Europa", Endereco = "Rua das Acácias", Numero = "120", Cep = "17013-000",
            AreaM2 = 230m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 2, Salas = 2, Iptu = 360m, ValorCondominio = 700m,
            Destaque = true
        },
        "Sobrado em condomínio para alugar, com ambientes amplos e área gourmet pronta para os fins de semana.",
        "O condomínio tem portaria 24 horas e câmeras. O Jardim Europa é bem localizado, perto de escolas, mercados e das principais avenidas.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"));

        Novo(3, new Imovel
        {
            Titulo = "Sobrado com quintal e área gourmet para alugar",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3900m,
            Cidade = "Bauru", Bairro = "Parque Jaraguá", Endereco = "Rua Antônio Alves", Numero = "512", Cep = "17020-000",
            AreaM2 = 140m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Iptu = 190m, ValorCondominio = 380m,
            Destaque = true
        },
        "Sobrado para alugar em condomínio, com quintal gramado e espaço de lazer completo para a família.",
        "Em região residencial e tranquila, com mercados, escolas e farmácias por perto e fácil acesso ao transporte público.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"));

        Novo(4, new Imovel
        {
            Titulo = "Sobrado amplo com lareira para alugar na Vila Cardia",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 4200m,
            Cidade = "Bauru", Bairro = "Vila Cardia", Endereco = "Rua Gustavo Maciel", Numero = "480", Cep = "17013-300",
            AreaM2 = 260m, Quartos = 3, Suites = 0, Banheiros = 2, VagasGaragem = 4, Salas = 2, Iptu = 280m
        },
        "Sobrado espaçoso para alugar, com sala ampla, lareira e pátio para vários veículos.",
        "Fica em bairro residencial consolidado, com comércio, padarias, escolas e pontos de ônibus próximos.",
        (IMV, "Móveis planejados"));

        Novo(5, new Imovel
        {
            Titulo = "Casa clássica com jardim para alugar no Jardim Europa",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 7500m,
            Cidade = "Bauru", Bairro = "Jardim Europa", Endereco = "Rua das Orquídeas", Numero = "95", Cep = "17013-050",
            AreaM2 = 320m, Quartos = 4, Suites = 2, Banheiros = 4, VagasGaragem = 3, Salas = 3, Iptu = 480m,
            Destaque = true
        },
        "Casa de estilo clássico para alugar, com jardim, deck e ambientes amplos, ideal para quem valoriza privacidade e charme.",
        "Em uma das regiões mais procuradas da cidade, perto de restaurantes, escolas e das principais avenidas.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"));

        // ===== Rodada 3 =====
        Novo(1, new Imovel
        {
            Titulo = "Apartamento de 2 quartos no Centro, pronto para morar",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 395000m,
            Cidade = "Bauru", Bairro = "Centro", Endereco = "Rua Batista de Carvalho", Numero = "4-50", Complemento = "Apto 101", Cep = "17015-000",
            AreaM2 = 68m, Quartos = 2, Suites = 1, Banheiros = 2, VagasGaragem = 1, Salas = 2, Andar = 10, Iptu = 130m, ValorCondominio = 540m
        },
        "Apartamento no coração da cidade, com varanda e vista aberta, pronto para morar ou para investir.",
        "O prédio tem elevador, portaria e academia. A localização permite resolver tudo a pé: bancos, comércio, restaurantes e transporte público.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"), (CON, "Elevador"), (CON, "Academia"), (SEG, "Portaria"));

        Novo(2, new Imovel
        {
            Titulo = "Sobrado em condomínio com 4 quartos no Jardim Panorama",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 980000m,
            Cidade = "Bauru", Bairro = "Jardim Panorama", Endereco = "Rua dos Jacarandás", Numero = "210", Cep = "17055-100",
            AreaM2 = 245m, Quartos = 4, Suites = 1, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 380m, ValorCondominio = 650m
        },
        "Sobrado confortável em condomínio fechado, com quartos amplos e uma área gourmet que é o coração da casa.",
        "O condomínio conta com portaria e câmeras e fica em região em crescimento, com fácil acesso às principais vias da cidade.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"));

        Novo(3, new Imovel
        {
            Titulo = "Sobrado de 3 quartos com churrasqueira e quintal gramado",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 690000m,
            Cidade = "Bauru", Bairro = "Vila Falcão", Endereco = "Rua Marcondes Salgado", Numero = "300", Cep = "17050-100",
            AreaM2 = 165m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 2, Salas = 2, Iptu = 230m, ValorCondominio = 450m
        },
        "Sobrado em condomínio com quintal de verdade, perfeito para quem tem filhos ou animais de estimação.",
        "A região é residencial, com padarias, supermercados e escolas próximas, e o condomínio tem portaria e câmeras.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (CON, "Salão de festas"), (SEG, "Portaria"), (SEG, "Câmeras"));

        Novo(4, new Imovel
        {
            Titulo = "Sobrado de 4 quartos com lareira e garagem para 5 carros",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 890000m,
            Cidade = "Bauru", Bairro = "Jardim Brasil", Endereco = "Rua Treze de Maio", Numero = "720", Cep = "17025-110",
            AreaM2 = 320m, Quartos = 4, Suites = 2, Banheiros = 4, VagasGaragem = 5, Salas = 2, Iptu = 390m,
            Destaque = true
        },
        "Sobrado grande e cheio de possibilidades, com fachada em pedra, lareira na sala e espaço de sobra para a família.",
        "Em rua arborizada, com acesso rápido às principais avenidas, comércio, escolas e hospitais.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"), (SEG, "Câmeras"));

        Novo(5, new Imovel
        {
            Titulo = "Casa de alto padrão com cozinha planejada na Vila Aviação",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 1420000m,
            Cidade = "Bauru", Bairro = "Vila Aviação", Endereco = "Rua Gustavo Maciel", Numero = "1500", Cep = "17018-000",
            AreaM2 = 300m, Quartos = 3, Suites = 3, Banheiros = 4, VagasGaragem = 3, Salas = 3, Iptu = 520m,
            Destaque = true
        },
        "Casa de alto padrão com três suítes, acabamento refinado e um jardim que traz tranquilidade para o dia a dia.",
        "Localizada em um dos bairros mais valorizados da cidade, com restaurantes, colégios e serviços por perto.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"), (SEG, "Câmeras"));

        // ===== Rodada 4 =====
        Novo(1, new Imovel
        {
            Titulo = "Apartamento de 3 quartos e 2 vagas para alugar",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3400m,
            Cidade = "Bauru", Bairro = "Jardim Panorama", Endereco = "Av. Getúlio Vargas", Numero = "2300", Complemento = "Apto 31", Cep = "17017-000",
            AreaM2 = 90m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Andar = 3, Iptu = 150m, ValorCondominio = 790m,
            Destaque = true
        },
        "Apartamento amplo para alugar, com três quartos, duas vagas de garagem e uma varanda que ilumina a sala.",
        "O condomínio tem elevador, portaria, câmeras e controle de acesso. O Jardim Panorama tem comércio completo e fácil acesso às principais avenidas.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"), (CON, "Elevador"), (SEG, "Portaria"), (SEG, "Câmeras"), (SEG, "Controle de acesso"));

        Novo(2, new Imovel
        {
            Titulo = "Sobrado de alto padrão em condomínio com 3 suítes",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 1320000m,
            Cidade = "Bauru", Bairro = "Altos da Cidade", Endereco = "Rua das Figueiras", Numero = "55", Cep = "17011-200",
            AreaM2 = 280m, Quartos = 4, Suites = 3, Banheiros = 5, VagasGaragem = 4, Salas = 3, Iptu = 470m, ValorCondominio = 850m,
            Destaque = true
        },
        "Sobrado de alto padrão em condomínio fechado, com três suítes, banheira de hidromassagem e uma área gourmet completa.",
        "O condomínio oferece portaria 24 horas, câmeras, controle de acesso e salão de festas, em um bairro nobre e bem servido de comércio e escolas.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Churrasqueira"), (CON, "Salão de festas"), (SEG, "Portaria"), (SEG, "Câmeras"), (SEG, "Controle de acesso"));

        Novo(3, new Imovel
        {
            Titulo = "Sobrado em condomínio com 3 quartos para alugar no Jardim Brasil",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3600m,
            Cidade = "Bauru", Bairro = "Jardim Brasil", Endereco = "Rua Jorge Tibiriçá", Numero = "140", Cep = "17025-200",
            AreaM2 = 145m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Iptu = 180m, ValorCondominio = 360m
        },
        "Sobrado para alugar com quintal gramado, playground e salão com churrasqueira, ótimo para quem tem crianças.",
        "O condomínio tem portaria e é tranquilo, perto de escolas, mercados e pontos de ônibus.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (SEG, "Portaria"));

        Novo(4, new Imovel
        {
            Titulo = "Sobrado de rua com 4 vagas e corredor coberto",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 690000m,
            Cidade = "Bauru", Bairro = "Jardim Contorno", Endereco = "Rua Aviador Gomes Ribeiro", Numero = "190", Cep = "17047-100",
            AreaM2 = 280m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 4, Salas = 2, Iptu = 310m
        },
        "Sobrado amplo com pátio para vários carros, ideal para quem precisa de espaço e quer valorizar o imóvel.",
        "Próximo a comércio, escolas e pontos de ônibus, em bairro residencial de fácil acesso às principais avenidas.",
        (IMV, "Suíte"), (IMV, "Móveis planejados"));

        Novo(5, new Imovel
        {
            Titulo = "Casa com 4 quartos e estantes embutidas para alugar",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 6200m,
            Cidade = "Bauru", Bairro = "Jardim Infante Dom Henrique", Endereco = "Rua Dom Pedro II", Numero = "330", Cep = "17012-250",
            AreaM2 = 280m, Quartos = 4, Suites = 1, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 430m
        },
        "Casa de estilo clássico para alugar, com jardim cuidado, pátio com deck e ambientes cheios de charme.",
        "Em bairro nobre e tranquilo, perto de restaurantes, escolas e do centro da cidade.",
        (IMV, "Suíte"), (IMV, "Móveis planejados"));

        // ===== Rodada 5 =====
        Novo(1, new Imovel
        {
            Titulo = "Apartamento de 3 quartos com 2 suítes e lazer completo",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 680000m,
            Cidade = "Bauru", Bairro = "Higienópolis", Endereco = "Rua Primeiro de Agosto", Numero = "90", Complemento = "Apto 122", Cep = "17011-000",
            AreaM2 = 105m, Quartos = 3, Suites = 2, Banheiros = 3, VagasGaragem = 2, Salas = 2, Andar = 12, Iptu = 220m, ValorCondominio = 880m,
            Destaque = true
        },
        "Apartamento no 12º andar, com duas suítes, varanda e ambientes amplos, perfeito para quem quer espaço e conforto.",
        "O condomínio oferece piscina, academia, salão de festas, elevador, portaria e controle de acesso, com acessibilidade em todas as áreas comuns.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"), (CON, "Piscina"), (CON, "Academia"), (CON, "Salão de festas"), (CON, "Elevador"),
        (SEG, "Portaria"), (SEG, "Controle de acesso"), (ACE, "Elevador"));

        Novo(2, new Imovel
        {
            Titulo = "Sobrado em condomínio com banheira e área gourmet",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 5400m,
            Cidade = "Bauru", Bairro = "Jardim Estoril", Endereco = "Rua dos Cedros", Numero = "37", Cep = "17016-300",
            AreaM2 = 250m, Quartos = 3, Suites = 2, Banheiros = 4, VagasGaragem = 3, Salas = 2, Iptu = 400m, ValorCondominio = 720m
        },
        "Sobrado para alugar em condomínio fechado, com suíte com banheira e uma área gourmet que convida a receber.",
        "O condomínio tem portaria e câmeras, e o Jardim Estoril reúne restaurantes, supermercados e escolas a poucos minutos.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"));

        Novo(3, new Imovel
        {
            Titulo = "Sobrado em condomínio com playground em Agudos",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 560000m,
            Cidade = "Agudos", Bairro = "Centro", Endereco = "Rua Quinze de Novembro", Numero = "410", Cep = "17120-000",
            AreaM2 = 150m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 2, Salas = 2, Iptu = 170m, ValorCondominio = 350m
        },
        "Sobrado em condomínio com quintal gramado e playground, uma ótima opção para morar perto de Bauru com mais espaço e sossego.",
        "Fica no centro de Agudos, com comércio, escolas e serviços por perto, e acesso rápido a Bauru.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (CON, "Salão de festas"), (SEG, "Portaria"));

        Novo(4, new Imovel
        {
            Titulo = "Sobrado amplo para alugar em Lençóis Paulista",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3100m,
            Cidade = "Lençóis Paulista", Bairro = "Centro", Endereco = "Rua Treze de Maio", Numero = "250", Cep = "18682-000",
            AreaM2 = 250m, Quartos = 3, Suites = 0, Banheiros = 2, VagasGaragem = 4, Salas = 2, Iptu = 200m
        },
        "Sobrado espaçoso para alugar, com sala ampla, lareira e pátio com espaço para vários veículos.",
        "Fica no centro de Lençóis Paulista, perto de comércio, bancos, escolas e serviços.",
        (IMV, "Móveis planejados"));

        Novo(5, new Imovel
        {
            Titulo = "Casa clássica com jardim e deck em Pederneiras",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 920000m,
            Cidade = "Pederneiras", Bairro = "Centro", Endereco = "Rua Coronel Cardoso", Numero = "180", Cep = "17280-000",
            AreaM2 = 290m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 330m
        },
        "Casa de estilo clássico com jardim, pergolado e deck, para quem busca charme, privacidade e muito espaço.",
        "Localizada no centro de Pederneiras, com comércio, escolas e serviços próximos e acesso rápido a Bauru.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"));

        // ===== Rodada 6 =====
        Novo(1, new Imovel
        {
            Titulo = "Apartamento de 3 quartos com varanda gourmet no Parque Jaraguá",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 485000m,
            Cidade = "Bauru", Bairro = "Parque Jaraguá", Endereco = "Avenida Nações Unidas", Numero = "12-45", Complemento = "Apto 41", Cep = "17011-000",
            AreaM2 = 78m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Andar = 4, Iptu = 160m, ValorCondominio = 650m,
            Destaque = true
        },
        "Apartamento bem localizado, com varanda gourmet, ambientes integrados e ótima ventilação.",
        "O condomínio tem elevador, portaria e salão de festas, e o bairro reúne mercados, farmácias e escolas a poucos passos.",
        (IMV, "Suíte"), (IMV, "Varanda"), (CON, "Elevador"), (CON, "Salão de festas"), (SEG, "Portaria"));

        Novo(2, new Imovel
        {
            Titulo = "Sobrado com banheira e jardim no Jardim Colonial",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 980000m,
            Cidade = "Bauru", Bairro = "Jardim Colonial", Endereco = "Rua das Hortênsias", Numero = "310", Cep = "17014-250",
            AreaM2 = 280m, Quartos = 4, Suites = 2, Banheiros = 4, VagasGaragem = 3, Salas = 3, Iptu = 390m, ValorCondominio = 540m
        },
        "Sobrado espaçoso em condomínio, com suíte de banheira, jardim e área gourmet para receber a família.",
        "O condomínio tem portaria, câmeras e ruas internas tranquilas, perto de escolas, padarias e do comércio do bairro.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"));

        Novo(3, new Imovel
        {
            Titulo = "Sobrado com playground e quintal para alugar no Jardim Contorno",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3400m,
            Cidade = "Bauru", Bairro = "Jardim Contorno", Endereco = "Rua Rio Branco", Numero = "412", Cep = "17047-100",
            AreaM2 = 170m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 2, Salas = 2, Iptu = 230m, ValorCondominio = 450m
        },
        "Sobrado para alugar em condomínio, com quintal gramado e playground para as crianças.",
        "Região residencial e arborizada, perto de escolas, mercados e das principais avenidas.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (CON, "Salão de festas"), (SEG, "Portaria"));

        NaLixeira(4, new Imovel
        {
            Titulo = "Sobrado com fachada em pedra e pátio amplo no Altos da Cidade",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 890000m,
            Cidade = "Bauru", Bairro = "Altos da Cidade", Endereco = "Rua Doutor Luiz Zuiani", Numero = "95", Cep = "17013-110",
            AreaM2 = 310m, Quartos = 4, Suites = 1, Banheiros = 3, VagasGaragem = 4, Salas = 2, Iptu = 360m
        },
        "Sobrado de rua com fachada em pedra, lareira e pátio amplo para vários veículos.",
        "Bairro valorizado, com acesso rápido ao centro, comércio e serviços.",
        (IMV, "Suíte"), (IMV, "Varanda"));

        Novo(5, new Imovel
        {
            Titulo = "Casa clássica com pergolado e jardim na Vila Mesquita",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 1050000m,
            Cidade = "Bauru", Bairro = "Vila Mesquita", Endereco = "Rua Aviador Gomes Ribeiro", Numero = "228", Cep = "17015-310",
            AreaM2 = 320m, Quartos = 4, Suites = 2, Banheiros = 4, VagasGaragem = 3, Salas = 2, Iptu = 370m
        },
        "Casa de estilo clássico, com pergolado, jardim bem cuidado e ambientes amplos.",
        "A Vila Mesquita é tranquila, com praças, restaurantes e fácil acesso às avenidas principais.",
        (IMV, "Suíte"), (IMV, "Varanda"), (IMV, "Móveis planejados"));

        // ===== Rodada 7 =====
        NaLixeira(1, new Imovel
        {
            Titulo = "Apartamento com 2 vagas e varanda para alugar na Vila Universitária",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 2650m,
            Cidade = "Bauru", Bairro = "Vila Universitária", Endereco = "Rua Engenheiro Saint Martin", Numero = "6-30", Complemento = "Apto 23", Cep = "17012-160",
            AreaM2 = 70m, Quartos = 2, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 1, Andar = 2, Iptu = 120m, ValorCondominio = 590m
        },
        "Apartamento pronto para morar, com varanda, cozinha aberta e duas vagas de garagem.",
        "Perto de universidades, supermercados e restaurantes, com transporte público na porta.",
        (IMV, "Suíte"), (IMV, "Varanda"), (CON, "Elevador"), (SEG, "Portaria"));

        NaLixeira(2, new Imovel
        {
            Titulo = "Sobrado de 4 suítes com área gourmet no Residencial Villaggio",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 1390000m,
            Cidade = "Bauru", Bairro = "Residencial Villaggio", Endereco = "Rua das Orquídeas", Numero = "77", Cep = "17018-500",
            AreaM2 = 340m, Quartos = 4, Suites = 4, Banheiros = 5, VagasGaragem = 4, Salas = 3, Iptu = 480m, ValorCondominio = 890m
        },
        "Sobrado de alto padrão em condomínio fechado, com quatro suítes e área gourmet completa.",
        "Condomínio com portaria 24 horas, câmeras e controle de acesso, em região nobre da cidade.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"), (SEG, "Controle de acesso"));

        Novo(3, new Imovel
        {
            Titulo = "Sobrado com churrasqueira e quintal gramado no Jardim Marambá",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 570000m,
            Cidade = "Bauru", Bairro = "Jardim Marambá", Endereco = "Rua Pedro de Toledo", Numero = "140", Cep = "17055-020",
            AreaM2 = 140m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Iptu = 190m, ValorCondominio = 380m
        },
        "Sobrado simples e acolhedor, com churrasqueira e quintal gramado.",
        "Região em crescimento, com comércio, escolas e acesso fácil às avenidas.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (SEG, "Portaria"));

        Novo(4, new Imovel
        {
            Titulo = "Sobrado espaçoso com lareira para alugar no Jardim América",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3300m,
            Cidade = "Bauru", Bairro = "Jardim América", Endereco = "Rua Capitão Prudente", Numero = "505", Cep = "17017-100",
            AreaM2 = 260m, Quartos = 4, Suites = 1, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 260m
        },
        "Sobrado amplo para alugar, com lareira, pátio coberto e quartos com armários embutidos.",
        "Bairro residencial, com mercados, padarias e escolas por perto.",
        (IMV, "Suíte"), (IMV, "Móveis planejados"));

        NaLixeira(5, new Imovel
        {
            Titulo = "Casa clássica com jardim e deck na Vila Falcão",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 1180000m,
            Cidade = "Bauru", Bairro = "Vila Falcão", Endereco = "Rua Gerson França", Numero = "260", Cep = "17050-000",
            AreaM2 = 300m, Quartos = 3, Suites = 2, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 350m
        },
        "Casa de estilo clássico, com jardim, deck de madeira e muita privacidade.",
        "Região valorizada, perto de restaurantes, escolas e do centro.",
        (IMV, "Suíte"), (IMV, "Varanda"));

        // ===== Rodada 8 =====
        Novo(1, new Imovel
        {
            Titulo = "Apartamento compacto de 2 quartos na Vila Santa Tereza",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 360000m,
            Cidade = "Bauru", Bairro = "Vila Santa Tereza", Endereco = "Rua Azarias Leite", Numero = "9-18", Complemento = "Apto 15", Cep = "17015-050",
            AreaM2 = 58m, Quartos = 2, Suites = 0, Banheiros = 1, VagasGaragem = 1, Salas = 1, Andar = 1, Iptu = 110m, ValorCondominio = 420m
        },
        "Apartamento compacto e funcional, ótimo para quem quer começar a vida em casa própria.",
        "Perto de comércio, bancos e transporte, com tudo ao alcance a pé.",
        (IMV, "Varanda"), (CON, "Elevador"), (SEG, "Portaria"));

        Novo(2, new Imovel
        {
            Titulo = "Sobrado em condomínio com 3 suítes para alugar em Agudos",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 4200m,
            Cidade = "Agudos", Bairro = "Residencial Jardim Europa", Endereco = "Rua das Acácias", Numero = "58", Cep = "17120-000",
            AreaM2 = 240m, Quartos = 3, Suites = 3, Banheiros = 4, VagasGaragem = 3, Salas = 2, Iptu = 280m, ValorCondominio = 620m,
            Destaque = true
        },
        "Sobrado com três suítes em condomínio, ideal para quem busca tranquilidade perto de Bauru.",
        "Condomínio com portaria e câmeras, em Agudos, com escolas e comércio por perto.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"));

        NaLixeira(3, new Imovel
        {
            Titulo = "Sobrado com playground em Lençóis Paulista",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 640000m,
            Cidade = "Lençóis Paulista", Bairro = "Jardim Cruzeiro", Endereco = "Rua Quinze de Novembro", Numero = "320", Cep = "18682-100",
            AreaM2 = 160m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Iptu = 200m
        },
        "Sobrado com quintal e playground, pensado para quem tem crianças.",
        "Em Lençóis Paulista, perto de escolas, mercados e serviços do dia a dia.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"));

        Novo(4, new Imovel
        {
            Titulo = "Sobrado com pátio amplo e corredor coberto em Pederneiras",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 700000m,
            Cidade = "Pederneiras", Bairro = "Jardim Paulista", Endereco = "Rua Dom Pedro II", Numero = "410", Cep = "17280-100",
            AreaM2 = 270m, Quartos = 4, Suites = 1, Banheiros = 3, VagasGaragem = 4, Salas = 2, Iptu = 240m
        },
        "Sobrado de rua com pátio amplo, corredor coberto e quartos espaçosos.",
        "Em Pederneiras, com comércio e escolas próximos e acesso rápido a Bauru.",
        (IMV, "Suíte"), (IMV, "Móveis planejados"));

        Novo(5, new Imovel
        {
            Titulo = "Casa clássica com jardim para alugar no Jardim Redentor",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3600m,
            Cidade = "Bauru", Bairro = "Jardim Redentor", Endereco = "Rua Primeiro de Agosto", Numero = "75", Cep = "17016-300",
            AreaM2 = 250m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 270m
        },
        "Casa clássica para alugar, com jardim, pergolado e ambientes amplos.",
        "Bairro tranquilo e bem localizado, perto de comércio, escolas e do centro.",
        (IMV, "Suíte"), (IMV, "Varanda"));

        NaLixeira(1, new Imovel
        {
            Titulo = "Apartamento de 3 quartos com lazer completo no Jardim Infante Dom Henrique",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 540000m,
            Cidade = "Bauru", Bairro = "Jardim Infante Dom Henrique", Endereco = "Rua Rui Barbosa", Numero = "14-60", Complemento = "Apto 91", Cep = "17012-340",
            AreaM2 = 84m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Andar = 9, Iptu = 170m, ValorCondominio = 700m
        },
        "Apartamento com lazer completo, varanda e ótima vista, em andar alto.",
        "Condomínio com piscina, academia, salão de festas e portaria 24 horas.",
        (IMV, "Suíte"), (IMV, "Varanda"), (CON, "Piscina"), (CON, "Academia"), (CON, "Salão de festas"), (SEG, "Portaria"));

        Novo(2, new Imovel
        {
            Titulo = "Sobrado com área gourmet para alugar no Jardim Paulista",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3900m,
            Cidade = "Bauru", Bairro = "Jardim Paulista", Endereco = "Rua Inconfidência", Numero = "133", Cep = "17030-000",
            AreaM2 = 230m, Quartos = 4, Suites = 2, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 250m, ValorCondominio = 480m
        },
        "Sobrado para alugar com área gourmet coberta, jardim e quartos amplos.",
        "Condomínio com portaria e câmeras, em região residencial e arborizada.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (SEG, "Portaria"), (SEG, "Câmeras"));

        // ===== Já vendidos e alugados (status Vendido / Alugado: continuam cadastrados, fora do site) =====
        Concluido(StatusImovel.Vendido, 1, new Imovel
        {
            Titulo = "Apartamento de 2 quartos com sacada na Vila Nova Cidade Universitária",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 410000m,
            Cidade = "Bauru", Bairro = "Vila Nova Cidade Universitária", Endereco = "Rua Doutor Cavalcanti", Numero = "5-12", Complemento = "Apto 31", Cep = "17012-440",
            AreaM2 = 64m, Quartos = 2, Suites = 1, Banheiros = 2, VagasGaragem = 1, Salas = 1, Andar = 3, Iptu = 130m, ValorCondominio = 480m
        },
        "Apartamento pronto para morar, com sacada e cozinha integrada.",
        "Perto de universidades, comércio e transporte público.",
        (IMV, "Varanda"), (CON, "Elevador"), (SEG, "Portaria"));

        Concluido(StatusImovel.Vendido, 2, new Imovel
        {
            Titulo = "Sobrado com piscina aquecida no Jardim Estoril",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 870000m,
            Cidade = "Bauru", Bairro = "Jardim Estoril", Endereco = "Rua Newton Prado", Numero = "290", Cep = "17015-480",
            AreaM2 = 250m, Quartos = 4, Suites = 2, Banheiros = 4, VagasGaragem = 3, Salas = 2, Iptu = 330m
        },
        "Sobrado com piscina aquecida, churrasqueira e quartos amplos.",
        "Bairro tranquilo, perto de escolas, mercados e restaurantes.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"), (IMV, "Varanda"));

        Concluido(StatusImovel.Vendido, 3, new Imovel
        {
            Titulo = "Casa com edícula e quintal no Jardim Bela Vista",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 495000m,
            Cidade = "Bauru", Bairro = "Jardim Bela Vista", Endereco = "Rua Joaquim Anacleto Bueno", Numero = "88", Cep = "17014-040",
            AreaM2 = 150m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Iptu = 175m
        },
        "Casa com edícula nos fundos e quintal para a família toda.",
        "Região residencial, com padaria, mercado e escolas por perto.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"));

        Concluido(StatusImovel.Vendido, 4, new Imovel
        {
            Titulo = "Sobrado de alto padrão com elevador na Vila Cardia",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 1250000m,
            Cidade = "Bauru", Bairro = "Vila Cardia", Endereco = "Rua Rio Branco", Numero = "960", Cep = "17014-000",
            AreaM2 = 330m, Quartos = 4, Suites = 3, Banheiros = 5, VagasGaragem = 4, Salas = 3, Iptu = 440m
        },
        "Sobrado de alto padrão, com elevador interno, quatro quartos e área gourmet.",
        "Bairro nobre e central, perto de restaurantes, hospitais e do comércio.",
        (IMV, "Suíte"), (IMV, "Móveis planejados"), (SEG, "Câmeras"));

        Concluido(StatusImovel.Vendido, 5, new Imovel
        {
            Titulo = "Casa clássica com jardim em Lençóis Paulista",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 760000m,
            Cidade = "Lençóis Paulista", Bairro = "Centro", Endereco = "Rua Treze de Maio", Numero = "512", Cep = "18682-020",
            AreaM2 = 280m, Quartos = 3, Suites = 2, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 260m
        },
        "Casa clássica com jardim bem cuidado e ambientes amplos.",
        "No centro de Lençóis Paulista, com tudo a poucos passos.",
        (IMV, "Suíte"), (IMV, "Varanda"));

        Concluido(StatusImovel.Vendido, 1, new Imovel
        {
            Titulo = "Apartamento compacto com 1 vaga no Jardim Panorama",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Venda, PrecoVenda = 330000m,
            Cidade = "Bauru", Bairro = "Jardim Panorama", Endereco = "Avenida Getúlio Vargas", Numero = "21-80", Complemento = "Apto 12", Cep = "17017-337",
            AreaM2 = 52m, Quartos = 2, Suites = 0, Banheiros = 1, VagasGaragem = 1, Salas = 1, Andar = 1, Iptu = 100m, ValorCondominio = 380m
        },
        "Apartamento compacto, ideal para começar a vida a dois.",
        "Em avenida movimentada, com comércio e ônibus na porta.",
        (CON, "Elevador"), (SEG, "Portaria"));

        Concluido(StatusImovel.Alugado, 1, new Imovel
        {
            Titulo = "Apartamento mobiliado de 1 quarto na Vila Aviação",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 2100m,
            Cidade = "Bauru", Bairro = "Vila Aviação", Endereco = "Rua Antônio Alves", Numero = "4-45", Complemento = "Apto 52", Cep = "17018-070",
            AreaM2 = 46m, Quartos = 1, Suites = 0, Banheiros = 1, VagasGaragem = 1, Salas = 1, Andar = 5, Iptu = 90m, ValorCondominio = 450m
        },
        "Apartamento mobiliado, pronto para entrar e morar.",
        "Perto de comércio, bancos e restaurantes.",
        (IMV, "Móveis planejados"), (CON, "Elevador"), (SEG, "Portaria"));

        Concluido(StatusImovel.Alugado, 2, new Imovel
        {
            Titulo = "Sobrado com churrasqueira para alugar no Jardim Europa",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3800m,
            Cidade = "Bauru", Bairro = "Jardim Europa", Endereco = "Rua Luiz Gama", Numero = "175", Cep = "17016-100",
            AreaM2 = 210m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 2, Salas = 2, Iptu = 240m
        },
        "Sobrado com churrasqueira e quintal para alugar.",
        "Bairro residencial, com mercados e escolas por perto.",
        (IMV, "Suíte"), (IMV, "Churrasqueira"));

        Concluido(StatusImovel.Alugado, 3, new Imovel
        {
            Titulo = "Casa de 3 quartos para alugar na Vila Souto",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 2500m,
            Cidade = "Bauru", Bairro = "Vila Souto", Endereco = "Rua Batista de Carvalho", Numero = "640", Cep = "17015-001",
            AreaM2 = 130m, Quartos = 3, Suites = 1, Banheiros = 2, VagasGaragem = 2, Salas = 2, Iptu = 170m
        },
        "Casa confortável para alugar, com quintal e garagem coberta.",
        "Perto do centro, com comércio e transporte à mão.",
        (IMV, "Suíte"));

        Concluido(StatusImovel.Alugado, 4, new Imovel
        {
            Titulo = "Sobrado amplo para alugar no Jardim Brasil",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 4500m,
            Cidade = "Bauru", Bairro = "Jardim Brasil", Endereco = "Rua Tenente Navarro", Numero = "315", Cep = "17020-100",
            AreaM2 = 300m, Quartos = 4, Suites = 2, Banheiros = 4, VagasGaragem = 4, Salas = 3, Iptu = 320m
        },
        "Sobrado amplo, com quatro quartos, escritório e pátio coberto.",
        "Bairro tranquilo e bem localizado.",
        (IMV, "Suíte"), (IMV, "Móveis planejados"), (SEG, "Câmeras"));

        Concluido(StatusImovel.Alugado, 5, new Imovel
        {
            Titulo = "Casa clássica para alugar em Pederneiras",
            Tipo = TipoImovel.Casa, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 3200m,
            Cidade = "Pederneiras", Bairro = "Centro", Endereco = "Rua Quinze de Novembro", Numero = "210", Cep = "17280-000",
            AreaM2 = 260m, Quartos = 3, Suites = 1, Banheiros = 3, VagasGaragem = 3, Salas = 2, Iptu = 230m
        },
        "Casa clássica para alugar, com jardim e ambientes amplos.",
        "No centro de Pederneiras, com tudo por perto.",
        (IMV, "Suíte"), (IMV, "Varanda"));

        Concluido(StatusImovel.Alugado, 1, new Imovel
        {
            Titulo = "Apartamento de 2 quartos para alugar no Jardim Infante Dom Henrique",
            Tipo = TipoImovel.Apartamento, Finalidade = FinalidadeImovel.Aluguel, PrecoAluguel = 1900m,
            Cidade = "Bauru", Bairro = "Jardim Infante Dom Henrique", Endereco = "Rua Treze de Maio", Numero = "7-22", Complemento = "Apto 24", Cep = "17012-300",
            AreaM2 = 60m, Quartos = 2, Suites = 0, Banheiros = 1, VagasGaragem = 1, Salas = 1, Andar = 2, Iptu = 95m, ValorCondominio = 410m
        },
        "Apartamento de dois quartos, bem ventilado e com vaga de garagem.",
        "Perto de comércio, escolas e transporte público.",
        (CON, "Elevador"), (SEG, "Portaria"));

        // ===== Gravação =====
        // Cada imóvel é identificado pelo título: só entram os que ainda não existem. Os novos vão para o corretor que tem
        // menos imóveis do mesmo tipo (disponíveis, vendidos/alugados ou na Lixeira): fica 12 + 4 + 2 para cada corretor.
        // Todas as datas ficam entre 12/10/2026 e 21/10/2026.
        var agora = DateTime.Now;
        var fim = FimEfetivo(agora);
        var limiteCadastro = PeriodoInicio.AddTicks((long)((fim - PeriodoInicio).Ticks * 0.7));   // cadastros nos primeiros dias; o resto fica para vendas, Lixeira e histórico

        var existentes = (await db.Imoveis.ToListAsync(ct)).GroupBy(i => i.Titulo).ToDictionary(g => g.Key, g => g.First());
        var todos = existentes.Values.ToList();
        var idsCorretores = corretores.Select(c => c.Id).ToList();

        static bool Concluida(Imovel i) => i.Status == StatusImovel.Vendido || i.Status == StatusImovel.Alugado;
        Dictionary<int, int> Carga(Func<Imovel, bool> filtro) =>
            idsCorretores.ToDictionary(id => id, id => todos.Count(i => i.CorretorId == id && filtro(i)));

        var cargaDisponiveis = Carga(i => i.DeletedAt == null && !Concluida(i));
        var cargaConcluidos = Carga(i => i.DeletedAt == null && Concluida(i));
        var cargaLixeira = Carga(i => i.DeletedAt != null);

        var posLixeira = 0;
        var posConcluido = 0;
        var novos = 0;
        var acertos = new List<(int Id, DateTime CriadoEm, DateTime? ExcluidoEm)>();

        for (var pos = 0; pos < catalogo.Count; pos++)
        {
            var (imovel, naLixeira) = catalogo[pos];
            var concluido = Concluida(imovel);
            var criadoEm = DataNoPeriodo(pos, catalogo.Count, limiteCadastro);

            if (existentes.TryGetValue(imovel.Titulo, out var atual))
            {
                // Já existe: só corrige datas que ficaram fora do período
                var foraDoPeriodo = atual.CreatedAt is null || atual.CreatedAt < PeriodoInicio || atual.CreatedAt > fim
                    || (atual.DeletedAt is { } del && (del < PeriodoInicio || del > fim || del < atual.CreatedAt));

                if (foraDoPeriodo)
                {
                    DateTime? excluidoEm = atual.DeletedAt is null ? null : Entre(criadoEm, fim, 0.4 + 0.1 * (posLixeira % 5));
                    acertos.Add((atual.Id, criadoEm, excluidoEm));
                }

                if (atual.DeletedAt is not null) posLixeira++;
                continue;
            }

            var carga = naLixeira ? cargaLixeira : concluido ? cargaConcluidos : cargaDisponiveis;
            var donoId = idsCorretores.OrderBy(id => carga[id]).ThenBy(id => id).First();
            carga[donoId]++;

            imovel.Codigo = await CodigoImovelHelper.ReservarAsync(db, ct);
            imovel.CorretorId = donoId;
            imovel.CreatedAt = criadoEm;
            imovel.UpdatedAt = criadoEm;

            if (naLixeira)
            {
                imovel.DeletedAt = Entre(criadoEm, fim, 0.4 + 0.1 * (posLixeira % 5));
                imovel.UpdatedAt = imovel.DeletedAt;
                posLixeira++;
            }
            else if (concluido)
            {
                // Data do negócio fechado (o dashboard conta vendas e aluguéis por esta data)
                imovel.UpdatedAt = Entre(criadoEm, fim, 0.3 + 0.1 * (posConcluido % 6));
                posConcluido++;
            }

            db.Imoveis.Add(imovel);
            novos++;
        }

        await db.SaveChangesAsync(ct);

        // Imóveis que já existiam com datas fora do período: acerta direto no banco (assim o "updated_at" não vira "agora")
        foreach (var (id, criadoEm, excluidoEm) in acertos)
        {
            var atualizadoEm = excluidoEm ?? criadoEm;
            await db.Imoveis.Where(i => i.Id == id).ExecuteUpdateAsync(set => set
                .SetProperty(i => i.CreatedAt, (DateTime?)criadoEm)
                .SetProperty(i => i.UpdatedAt, (DateTime?)atualizadoEm)
                .SetProperty(i => i.DeletedAt, excluidoEm), ct);
        }

        // Na Lixeira o status é sempre Inativo (vale também para imóveis que já estavam no banco)
        await db.Imoveis
            .Where(i => i.DeletedAt != null && i.Status != StatusImovel.Inativo)
            .ExecuteUpdateAsync(set => set.SetProperty(i => i.Status, StatusImovel.Inativo), ct);
        logger.LogWarning("{Novos} imóveis de TESTE cadastrados, com fotos reais (apenas em Development). Remova o seed quando não precisar mais dele.", novos);

        await SeedHistoricoAsync(db, catalogo.Select(x => x.Imovel.Titulo).ToList(), acertos.Count > 0, fim, logger, ct);
    }

    /// <summary>
    /// TEMPORÁRIO (apenas desenvolvimento): histórico de exemplo para a página Histórico, com todas as ações do sistema:
    /// imóveis (cadastrado, editado, status, publicação, corretor, Lixeira, restaurado, excluído permanentemente),
    /// corretores e usuários. Todas as datas ficam entre 12/10/2026 e 21/10/2026.
    /// Cada imóvel de teste sem nenhum registro ganha o seu; os grupos de corretor, usuário e exclusão permanente só entram
    /// se a ação ainda não existir. Se o banco tiver histórico de testes anterior (com datas fora do período) ou se as datas
    /// dos imóveis foram acertadas agora, o histórico de teste é apagado e refeito dentro do período.
    /// </summary>
    private static async Task SeedHistoricoAsync(
        AppDbContext db, List<string> titulos, bool datasAcertadas, DateTime fim, ILogger logger, CancellationToken ct)
    {
        var marcos = await db.Usuarios.Include(u => u.Corretor).FirstOrDefaultAsync(u => u.Email == EmailMarcos, ct);
        var juliana = await db.Usuarios.FirstOrDefaultAsync(u => u.Email == EmailJuliana, ct);
        if (marcos is null || juliana is null) return;

        // Histórico de testes antigo (fora do período) ou datas de imóveis acertadas: refaz tudo dentro do período
        if (datasAcertadas || await db.Historicos.AnyAsync(h => h.DataHora < PeriodoInicio, ct))
        {
            db.Historicos.RemoveRange(await db.Historicos.ToListAsync(ct));
            await db.SaveChangesAsync(ct);
        }

        var emailsEquipe = Equipe.Select(p => p.Email).ToList();
        var corretores = await db.Corretores.Include(c => c.Usuario)
            .Where(c => c.Email != null && emailsEquipe.Contains(c.Email))
            .OrderBy(c => c.Id)
            .ToListAsync(ct);

        var imoveis = await db.Imoveis.AsNoTracking()
            .Include(i => i.Corretor)
            .Where(i => titulos.Contains(i.Titulo))
            .OrderBy(i => i.CreatedAt).ThenBy(i => i.Id)
            .ToListAsync(ct);

        var comHistorico = (await db.Historicos.Where(h => h.ImovelId != null).Select(h => h.ImovelId!.Value).Distinct().ToListAsync(ct)).ToHashSet();
        var total = 0;

        void Add(int usuarioId, string acao, string? descricao, int? imovelId, DateTime quando)
        {
            db.Historicos.Add(new Historico
            {
                UsuarioId = usuarioId,
                Acao = acao,
                Descricao = descricao,
                ImovelId = imovelId,
                DataHora = quando > fim ? fim : quando < PeriodoInicio ? PeriodoInicio : quando
            });
            total++;
        }

        // Dia e hora fixos dentro do período (dia 0 = 12/10, ..., dia 9 = 21/10)
        DateTime Dia(int dia, int hora, int minuto) => PeriodoInicio.Date.AddDays(dia).AddHours(hora).AddMinutes(minuto);

        static string Ref(Imovel i) => $"{i.Titulo} (cód. {i.Codigo})";
        var disponivel = ImovelTexto.NomeStatus(StatusImovel.Disponivel);
        var reservado = ImovelTexto.NomeStatus(StatusImovel.Reservado);

        // ---------- Imóveis ----------
        var k = 0;
        foreach (var imovel in imoveis.Where(i => !comHistorico.Contains(i.Id)))
        {
            var dono = imovel.Corretor?.UsuarioId ?? marcos.Id;
            var outro = corretores.FirstOrDefault(c => c.Id != imovel.CorretorId);
            var criacao = imovel.CreatedAt ?? Dia(0, 9, 0);

            // Cadastro: ora o próprio corretor, ora um administrador
            var autorCadastro = (k % 3) switch { 0 => dono, 1 => marcos.Id, _ => juliana.Id };
            Add(autorCadastro, "Imóvel cadastrado", Ref(imovel), imovel.Id, criacao);

            if (k % 2 == 0)
                Add(dono, "Imóvel editado", $"{Ref(imovel)}.", imovel.Id, Entre(criacao, fim, 0.10));

            if (k % 4 == 1)
            {
                Add(marcos.Id, "Status alterado", $"{Ref(imovel)}: de {disponivel} para {reservado}.", imovel.Id, Entre(criacao, fim, 0.25));
                Add(marcos.Id, "Status alterado", $"{Ref(imovel)}: de {reservado} para {disponivel}.", imovel.Id, Entre(criacao, fim, 0.40));
            }

            if (k % 5 == 2)
            {
                Add(juliana.Id, "Imóvel retirado do site", Ref(imovel), imovel.Id, Entre(criacao, fim, 0.30));
                Add(juliana.Id, "Imóvel publicado", Ref(imovel), imovel.Id, Entre(criacao, fim, 0.45));
            }

            if (k % 6 == 3 && outro is not null && imovel.Corretor is not null)
                Add(marcos.Id, "Corretor atribuído", $"{Ref(imovel)}: de {outro.Nome} para {imovel.Corretor.Nome}.", imovel.Id, Entre(criacao, fim, 0.15));

            if (k % 9 == 4 && outro is not null)
            {
                Add(juliana.Id, "Corretor removido", $"{Ref(imovel)}: removido o corretor {outro.Nome}.", imovel.Id, Entre(criacao, fim, 0.08));
                Add(juliana.Id, "Corretor atribuído", $"{Ref(imovel)}: atribuído a {imovel.Corretor?.Nome ?? marcos.Nome}.", imovel.Id, Entre(criacao, fim, 0.12));
            }

            // Vendido ou alugado: o status mudou na data do negócio
            if (imovel.Status is StatusImovel.Vendido or StatusImovel.Alugado)
                Add(dono, "Status alterado",
                    $"{Ref(imovel)}: de {disponivel} para {ImovelTexto.NomeStatus(imovel.Status)}.",
                    imovel.Id, imovel.UpdatedAt ?? Entre(criacao, fim, 0.5));

            // Foi para a Lixeira (e continua lá)
            if (imovel.DeletedAt is { } excluidoEm)
                Add(k % 2 == 0 ? dono : marcos.Id, HistoricoAcoes.Excluido, $"{Ref(imovel)}: enviado para a Lixeira.", imovel.Id, excluidoEm);

            // Um que foi excluído e depois restaurado
            if (imovel.DeletedAt is null && imovel.Status == StatusImovel.Disponivel && k == 6)
            {
                Add(marcos.Id, HistoricoAcoes.Excluido, $"{Ref(imovel)}: enviado para a Lixeira.", imovel.Id, Entre(criacao, fim, 0.50));
                Add(marcos.Id, HistoricoAcoes.Restaurado, $"{Ref(imovel)}: restaurado da Lixeira.", imovel.Id, Entre(criacao, fim, 0.56));
            }

            k++;
        }

        // ---------- Imóveis apagados da Lixeira para sempre (sem vínculo com um imóvel que ainda existe) ----------
        if (!await db.Historicos.AnyAsync(h => h.Acao == HistoricoAcoes.ExcluidoDefinitivamente, ct))
        {
            // Os dois códigos de exemplo já foram "emitidos" por imóveis que não existem mais: ficam reservados para sempre
            await db.Database.ExecuteSqlRawAsync(
                "INSERT IGNORE INTO codigos_imovel (codigo, criado_em) VALUES ('F8K3T', UTC_TIMESTAMP(6)), ('Z4P9M', UTC_TIMESTAMP(6))", ct);

            Add(marcos.Id, HistoricoAcoes.Excluido, "Casa de 2 quartos no Jardim Carolina (cód. F8K3T): enviado para a Lixeira.", null, Dia(5, 9, 20));
            Add(marcos.Id, HistoricoAcoes.ExcluidoDefinitivamente, "Casa de 2 quartos no Jardim Carolina (cód. F8K3T): apagado da Lixeira para sempre.", null, Dia(6, 16, 40));
            Add(juliana.Id, HistoricoAcoes.ExcluidoDefinitivamente, "Terreno de esquina na Vila Nova (cód. Z4P9M): apagado da Lixeira para sempre.", null, Dia(8, 11, 15));
        }

        // ---------- Corretores e usuários ----------
        if (!await db.Historicos.AnyAsync(h => h.Acao == HistoricoAcoes.CorretorCadastrado, ct))
        {
            var lucas = corretores.FirstOrDefault(c => c.Email == "lucas@betelimoveis.com.br");
            var camila = corretores.FirstOrDefault(c => c.Email == "camila@betelimoveis.com.br");

            // Usuário e corretores cadastrados nos primeiros dias
            Add(marcos.Id, HistoricoAcoes.UsuarioCadastrado, $"{juliana.Nome} (usuário {juliana.Id}), acesso como administrador.", null, Dia(0, 8, 15));
            if (lucas is not null)
                Add(marcos.Id, HistoricoAcoes.CorretorCadastrado, $"{lucas.Nome} (corretor {lucas.Id})", null, Dia(0, 9, 40));
            if (camila is not null)
                Add(juliana.Id, HistoricoAcoes.CorretorCadastrado, $"{camila.Nome} (corretor {camila.Id})", null, Dia(0, 10, 30));

            if (lucas is not null)
                Add(marcos.Id, HistoricoAcoes.CorretorEditado, $"{lucas.Nome} (corretor {lucas.Id})", null, Dia(1, 14, 5));
            Add(marcos.Id, HistoricoAcoes.TipoAcessoAlterado, $"{marcos.Nome} (usuário {marcos.Id}): de administrador para administrador e corretor.", null, Dia(1, 16, 20));
            Add(juliana.Id, HistoricoAcoes.UsuarioEditado, $"{juliana.Nome} (usuário {juliana.Id})", null, Dia(2, 11, 0));
            Add(marcos.Id, HistoricoAcoes.SenhaRedefinida, $"{juliana.Nome} (usuário {juliana.Id})", null, Dia(2, 15, 30));

            if (camila is not null)
            {
                Add(marcos.Id, HistoricoAcoes.CorretorInativado, $"{camila.Nome} (corretor {camila.Id})", null, Dia(3, 9, 10));
                Add(marcos.Id, HistoricoAcoes.CorretorAtivado, $"{camila.Nome} (corretor {camila.Id})", null, Dia(3, 17, 45));
            }

            Add(marcos.Id, HistoricoAcoes.UsuarioInativado, $"{juliana.Nome} (usuário {juliana.Id})", null, Dia(4, 10, 20));
            Add(marcos.Id, HistoricoAcoes.UsuarioAtivado, $"{juliana.Nome} (usuário {juliana.Id})", null, Dia(4, 10, 50));
        }

        await db.SaveChangesAsync(ct);
        logger.LogWarning("{Total} registros de histórico de TESTE criados, entre 12/10/2026 e 21/10/2026 (apenas em Development).", total);
    }
}
