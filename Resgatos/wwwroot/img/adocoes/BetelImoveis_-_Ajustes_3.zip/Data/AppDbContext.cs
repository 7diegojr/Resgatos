using BetelImoveis.Models.Entities;
using BetelImoveis.Models.Enums;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;
using System.Text.RegularExpressions;

namespace BetelImoveis.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Usuario> Usuarios => Set<Usuario>();
    public DbSet<UsuarioPerfil> UsuarioPerfis => Set<UsuarioPerfil>();
    public DbSet<Corretor> Corretores => Set<Corretor>();
    public DbSet<Imovel> Imoveis => Set<Imovel>();
    public DbSet<CodigoImovel> CodigosImovel => Set<CodigoImovel>();
    public DbSet<FotoImovel> FotosImovel => Set<FotoImovel>();
    public DbSet<Diferencial> Diferenciais => Set<Diferencial>();
    public DbSet<ImovelDiferencial> ImovelDiferenciais => Set<ImovelDiferencial>();
    public DbSet<Historico> Historicos => Set<Historico>();

    // Leads, clientes, interações e visitas
    public DbSet<Lead> Leads => Set<Lead>();
    public DbSet<LeadImovel> LeadImoveis => Set<LeadImovel>();
    public DbSet<Cliente> Clientes => Set<Cliente>();
    public DbSet<ClienteImovel> ClienteImoveis => Set<ClienteImovel>();
    public DbSet<Interacao> Interacoes => Set<Interacao>();
    public DbSet<Visita> Visitas => Set<Visita>();

    /// <summary>
    /// Grava enums em MAIÚSCULAS (ex.: DISPONIVEL), como nos ENUMs da documentação. Nomes com mais de uma palavra
    /// ganham "_" entre elas (EmAtendimento → EM_ATENDIMENTO). Os enums antigos têm uma palavra só e não mudam.
    /// </summary>
    private static ValueConverter<TEnum, string> EnumMaiusculo<TEnum>() where TEnum : struct, Enum
        => new ValueConverter<TEnum, string>(
            v => EnumParaTexto(v.ToString()),
            s => Enum.Parse<TEnum>(s.Replace("_", ""), true));

    private static string EnumParaTexto(string nome)
        => Regex.Replace(nome, "(?<=[a-z0-9])(?=[A-Z])", "_").ToUpperInvariant();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Usuario>(e =>
        {
            e.HasIndex(x => x.Email).IsUnique();
        });

        // Um usuário pode ter mais de um perfil (Administrador e/ou Corretor)
        modelBuilder.Entity<UsuarioPerfil>(e =>
        {
            e.HasKey(x => new { x.UsuarioId, x.Perfil });
            e.Property(x => x.Perfil).HasConversion(EnumMaiusculo<TipoUsuario>()).HasMaxLength(20);
            e.HasOne(x => x.Usuario)
                .WithMany(x => x.Perfis)
                .HasForeignKey(x => x.UsuarioId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Corretor>(e =>
        {
            e.HasIndex(x => x.UsuarioId).IsUnique();
            e.HasOne(x => x.Usuario)
                .WithOne(x => x.Corretor)
                .HasForeignKey<Corretor>(x => x.UsuarioId)
                .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Imovel>(e =>
        {
            // Código público de 5 caracteres: único no banco (o "nunca reutilizado" vem da tabela codigos_imovel)
            e.HasIndex(x => x.Codigo).IsUnique();

            e.Property(x => x.Tipo).HasConversion(EnumMaiusculo<TipoImovel>()).HasMaxLength(20);
            e.Property(x => x.Finalidade).HasConversion(EnumMaiusculo<FinalidadeImovel>()).HasMaxLength(20);
            e.Property(x => x.Status).HasConversion(EnumMaiusculo<StatusImovel>()).HasMaxLength(20);

            e.HasOne(x => x.Corretor)
                .WithMany(x => x.Imoveis)
                .HasForeignKey(x => x.CorretorId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<FotoImovel>(e =>
        {
            e.HasOne(x => x.Imovel)
                .WithMany(x => x.Fotos)
                .HasForeignKey(x => x.ImovelId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Diferencial>(e =>
        {
            e.Property(x => x.Categoria).HasConversion(EnumMaiusculo<CategoriaDiferencial>()).HasMaxLength(30);
        });

        modelBuilder.Entity<ImovelDiferencial>(e =>
        {
            e.HasKey(x => new { x.ImovelId, x.DiferencialId });

            e.HasOne(x => x.Imovel)
                .WithMany(x => x.Diferenciais)
                .HasForeignKey(x => x.ImovelId)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.Diferencial)
                .WithMany(x => x.Imoveis)
                .HasForeignKey(x => x.DiferencialId)
                .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Historico>(e =>
        {
            e.HasOne(x => x.Usuario)
                .WithMany(x => x.Historicos)
                .HasForeignKey(x => x.UsuarioId)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x => x.Imovel)
                .WithMany(x => x.Historicos)
                .HasForeignKey(x => x.ImovelId)
                .OnDelete(DeleteBehavior.SetNull);
        });

        ConfigurarLeads(modelBuilder);
    }

    /// <summary>
    /// Leads, clientes, interações e visitas. Excluir imóvel, corretor ou cliente nunca apaga lead (SET NULL).
    /// Excluir um lead (exclusão de dados, LGPD) leva junto as ligações com imóveis, as interações e as visitas (CASCADE).
    /// </summary>
    private static void ConfigurarLeads(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Lead>(e =>
        {
            e.Property(x => x.Origem).HasConversion(EnumMaiusculo<OrigemLead>()).HasMaxLength(20);
            e.Property(x => x.Status).HasConversion(EnumMaiusculo<StatusLead>()).HasMaxLength(20);
            e.Property(x => x.MotivoPerda).HasConversion(EnumMaiusculo<MotivoPerda>()).HasMaxLength(30);
            e.Property(x => x.TipoNegocio).HasConversion(EnumMaiusculo<FinalidadeImovel>()).HasMaxLength(20);

            e.HasIndex(x => x.Status);
            e.HasIndex(x => x.CorretorId);
            e.HasIndex(x => x.CreatedAt);
            e.HasIndex(x => x.TelefoneNormalizado);

            e.HasOne(x => x.Imovel).WithMany().HasForeignKey(x => x.ImovelId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.Corretor).WithMany().HasForeignKey(x => x.CorretorId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.Cliente).WithMany(x => x.Leads).HasForeignKey(x => x.ClienteId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<LeadImovel>(e =>
        {
            e.HasKey(x => new { x.LeadId, x.ImovelId });

            e.HasOne(x => x.Lead).WithMany(x => x.Imoveis).HasForeignKey(x => x.LeadId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Imovel).WithMany(x => x.Leads).HasForeignKey(x => x.ImovelId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<ClienteImovel>(e =>
        {
            e.HasKey(x => new { x.ClienteId, x.ImovelId });

            e.HasOne(x => x.Cliente).WithMany(x => x.Imoveis).HasForeignKey(x => x.ClienteId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Imovel).WithMany().HasForeignKey(x => x.ImovelId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<Cliente>(e =>
        {
            e.HasIndex(x => x.TelefoneNormalizado);

            e.HasOne(x => x.CorretorResponsavel).WithMany().HasForeignKey(x => x.CorretorResponsavelId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Interacao>(e =>
        {
            e.Property(x => x.Tipo).HasConversion(EnumMaiusculo<TipoInteracao>()).HasMaxLength(20);

            e.HasOne(x => x.Lead).WithMany(x => x.Interacoes).HasForeignKey(x => x.LeadId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Cliente).WithMany(x => x.Interacoes).HasForeignKey(x => x.ClienteId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Usuario).WithMany().HasForeignKey(x => x.UsuarioId).OnDelete(DeleteBehavior.SetNull);
        });

        modelBuilder.Entity<Visita>(e =>
        {
            e.Property(x => x.Status).HasConversion(EnumMaiusculo<StatusVisita>()).HasMaxLength(20);
            e.Property(x => x.Interesse).HasConversion(EnumMaiusculo<InteresseVisita>()).HasMaxLength(20);

            e.HasIndex(x => x.DataHora);

            e.HasOne(x => x.Lead).WithMany(x => x.Visitas).HasForeignKey(x => x.LeadId).OnDelete(DeleteBehavior.Cascade);
            e.HasOne(x => x.Imovel).WithMany().HasForeignKey(x => x.ImovelId).OnDelete(DeleteBehavior.SetNull);
            e.HasOne(x => x.Corretor).WithMany().HasForeignKey(x => x.CorretorId).OnDelete(DeleteBehavior.SetNull);
        });
    }

    public override Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
    {
        PreencherDatas();
        return base.SaveChangesAsync(cancellationToken);
    }

    public override int SaveChanges()
    {
        PreencherDatas();
        return base.SaveChanges();
    }

    /// <summary>Preenche created_at / updated_at automaticamente.</summary>
    private void PreencherDatas()
    {
        var agora = DateTime.Now;

        foreach (var entry in ChangeTracker.Entries())
        {
            if (entry.State == Microsoft.EntityFrameworkCore.EntityState.Added)
            {
                switch (entry.Entity)
                {
                    case Usuario u: u.CreatedAt ??= agora; u.UpdatedAt ??= agora; break;
                    case Corretor c: c.CreatedAt ??= agora; c.UpdatedAt ??= agora; break;
                    case Imovel i: i.CreatedAt ??= agora; i.UpdatedAt ??= agora; break;
                    case FotoImovel f: f.CreatedAt ??= agora; break;
                    case Lead l: l.CreatedAt ??= agora; l.UpdatedAt ??= agora; l.EtapaAlteradaEm ??= agora; break;
                    case LeadImovel li: li.CreatedAt ??= agora; break;
                    case ClienteImovel ci: ci.CreatedAt ??= agora; break;
                    case Cliente cl: cl.CreatedAt ??= agora; cl.UpdatedAt ??= agora; break;
                    case Visita v: v.CreatedAt ??= agora; break;
                }
            }
            else if (entry.State == Microsoft.EntityFrameworkCore.EntityState.Modified)
            {
                switch (entry.Entity)
                {
                    case Usuario u: u.UpdatedAt = agora; break;
                    case Corretor c: c.UpdatedAt = agora; break;
                    case Imovel i: i.UpdatedAt = agora; break;
                    case Lead l: l.UpdatedAt = agora; break;
                    case Cliente cl: cl.UpdatedAt = agora; break;
                }
            }
        }
    }
}
